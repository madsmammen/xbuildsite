<?php
/**
 * File: xbuild.php
 * Description:
 * -------------
 */
  function xbuild__getRowNum($app, $table, $site) {
    $num = 0;
    $query = "select count(*) from `xBuildSite__fields` where `tableName` = '$table' and `site` = '$site'";
    DLog::log("\$query: $query");

    $res = xf_db_query($query, $app->db());
    if ($res) {
      $row = xf_db_fetch_array($res, MYSQL_NUM);
      $num = $row[0];
      DLog::log("num: $num");
    }
    return($num);
  }
  // $app =& Dataface_Application::getInstance();
  // $_SESSION['xsite'] =  "time";
  // echo "_SESSION " . $_POST['xsite'];
  // DLog::log("_SESSION");

  // DLog::log("user: " .$_SERVER['PHP_AUTH_USER']);

  if ($_POST) {
    if (isset($_POST['selectSite'])) {
      DLog::log("selectSite");
      $response =& Dataface_Application::getResponse();
      switch ($_POST['selectSite']) {
        case "NEW":
          $site = $_POST['__xbuild_site__'];
          $db = $app->_conf['_database']['name']; // $_POST['__xbuild_db__'];
	  DLog::Log("New Site... '$site'");

	  $insert = "UPDATE `xBuildSite__userinfo` set `currSite` = '" . $site . "', currTable = '' " .
	            " where `userName` = 'xAdmin'";
          $res = xf_db_query($insert, $app->db());
          if ($res) {
            DLog::log("OK: $res");
            // $response['--msg'] = "XbuildSite description for: '$site' created";
	    $insert = "INSERT INTO `xBuildSite__sites` (`site`, `discName`, `title`, `database`, `heading`, `auth`, `path`) " .
		    " values ('" . $site . "', 'my" . ucfirst($site) . "', '" . $site . "', '" . $db .
		    "', '<font size=5>" . ucfirst($site) . ": Frontend database applications</font>', 'noAuth', 'xbSites')";
            DLog::log("\$insert: $insert");
  
            $res = xf_db_query($insert, $app->db());
            if ($res) {
              DLog::log("OK: $res");
              $response['--msg'] = "XbuildSite description for: '$site' created";
  
	    }
	  }

	  break;
  
        case "DEL":
	  $rc = false;
          $site = $_POST['__xbuild_site__'];
	  DLog::Log("Delete Site... '$site'");
          $query = "delete from `xBuildSite__sites` where `site` = '" . $site . "'";
          DLog::log("\$query: $query");
  
          $res = xf_db_query($query, $app->db());
          if ($res) {
            DLog::log("OK: $res");
	    $rc = true;

            $query = "delete from `xBuildSite__tables` where `site` = '" . $site . "'";
            $res = xf_db_query($query, $app->db());
            if ($res) {
	      $rc = true;
              $query = "delete from `xBuildSite__fields` where `site` = '" . $site . "'";
              $res = xf_db_query($query, $app->db());
              if ($res) {
	        $rc = true;
		$update = "UPDATE `xBuildSite__userinfo` SET `currSite` = '', `currTable` = '' " .
		          "where `userName` = 'xAdmin'";
                DLog::log("\$update: $update");
                $res = xf_db_query($update, $app->db());
                if ($res) {
                  DLog::log("OK: $res");
	        }
	      }
	    }
	  }
	  if ($rc) 
            $response['--msg'] = "XbuildSite description for: '$site' deleted";
	  else
            $response['--msg'] = "FAILED ! XbuildSite description for: '$site' deleted";
	  break;
  
        default:
	  DLog::Log("Default: " . $_POST['selectSite']);
	  $currTable = '';
	  /* Find new current table */
	  $select = "select `tableName` from `xBuildSite__tables` where `site` != '" .  $_POST['selectSite'] . "'";
          DLog::log("\$select: $select");
          $res = xf_db_query($select, $app->db());
          if ($res) {
            DLog::log("select OK: $res");
            $row = xf_db_fetch_array($res, MYSQL_NUM);
	    $currTable = $row[0];
            DLog::log("currTable: $currTable");
	  } 
	  else
            DLog::log("select FAILED: $res");

	  $update = "UPDATE `xBuildSite__userinfo` SET `currSite` = '" . $_POST['selectSite'] . "'" .
	            ", `currTable` = '" . $currTable . "' where `userName` = 'xAdmin'";
          DLog::log("\$update: $update");
          $res = xf_db_query($update, $app->db());
          if ($res) {
            DLog::log("OK: $res");
	  }
      }
    }
    
    if (isset($_POST['table_name'])) {
      DLog::log("table_name: " . $_POST['table_name']);
      if ($_POST['table_name'] == "DEL_TABLE") {
        $site = $_POST['__xbuild_site__'];
        $table = $_POST['__xbuild_table__'];
        DLog::log("#### DEL_TABLE $table");
        $num = xbuild__getRowNum($app, $table, $site);
	if ($num == 0) {
          $response['--msg'] = "XbuildSite delete failed - no table loaded !";
	} else {
          /* xBuildSite__fields */
          $query = "delete from `xBuildSite__fields` where `tableName` = '" . $table . "' and `site` = '$site'";
          DLog::log("\$query: $query");
  
          $res = xf_db_query($query, $app->db());
          if ($res) {
            DLog::log("OK: $res");
            $response['--msg'] = "XbuildSite description for: '$table' deleted";

	    /* xBuildSite_tables */
            $query = "delete from `xBuildSite__tables` where `tableName` = '" . $table . "' and `site` = '$site'";
            DLog::log("\$query: $query");
  
            $res = xf_db_query($query, $app->db());
            if ($res) {
              DLog::log("OK: $res");
	    }
	  }
	  else {
            DLog::log("Failed: $res");
            $response['--msg'] = "XbuildSite delete description for: '$table' failed !";
	  }

          $query = "SELECT distinct `tableName` FROM `xbuildsite__fields` WHERE `site`= '$site'";
          DLog::log("\$query: $query");
	  $curr = '';
          $res = xf_db_query($query, $app->db());
          while ($row = xf_db_fetch_array($res, MYSQL_NUM)) {
            DLog::log(">>> \$row: $row[0]");
	    $curr = $row[0];
	  }
	  $update = "UPDATE `xBuildSite__userinfo` set `currTable` = '$curr' where `currSite` = '$site'";
          DLog::log("\$update: $update");
          $res = xf_db_query($update, $app->db());
          if ($res)
            DLog::log("UPDATE OK: $res");
	  else
            DLog::log("UPDATE FAILED: $res");

	}
      }
      else {
        $insert = "Update `XbuildSite__userinfo` set `currTable` = '" . $_POST['table_name'] . "' where userName = 'xAdmin'";
        DLog::log("\$insert: $insert");
 
        $ires = xf_db_query($insert, $app->db());
        if ($ires) {
          DLog::log("insert OK");
        }
      }
    }
    if (isset($_POST['__xbuild'])) {
      // require_once 'xbuild.php';

      $response =& Dataface_Application::getResponse();
       // get reference to response array

      // echo "\$_POST['__xbuild']: " . $_POST['__xbuild'];
      DLog::log("\$_POST['__xbuild']: " . $_POST['__xbuild']);
      // $site = $_POST['xbuild__site'];
      $site = $_POST['__xbuild_site__'];
      // $table = $_POST['xbuild__table'];
      $table = $_POST['__xbuild_table__'];

      switch ($_POST['__xbuild']) {
        case "Load":
          DLog::log("got 'Load' " . $_POST['selectTable'] . " Database table");
          $num = xbuild__getRowNum($app, $table, $site);
	  if ($num > 0) {
            $response['--msg'] = "XbuildSite load failed - table already loaded !";
	  } else {
            $query = "show columns from `" . $table . "`";
            DLog::log("==>>\$query: $query");

            $res = xf_db_query($query, $app->db());
            if ($res) {
	      /* 'XbuildSile__fields */
              DLog::log("$res");
              while ($row = xf_db_fetch_array($res, MYSQL_NUM)) {
	        DLog::log("Field: $row[0], Type: $row[1], Null: $row[2], Key: $row[3], " .
                          "Default: $row[4], Extra: $row[5]");
	        $insert = "INSERT INTO `XbuildSite__fields`";
	        $insert = $insert . " (`site`, `tableName`, `columnName`, `declared`, `isNull`, `vis`, `nullGrp`) values ( ";
	        $insert = $insert . "'" . $site . "', '" . $table . "', '$row[0]', '$row[1]', '$row[2]', 'Visible', '');";
                DLog::log("\$insert: $insert");
  
                $ires = xf_db_query($insert, $app->db());
                if ($ires) {
                  DLog::log("insert OK");
                  $response['--msg'] = "XbuildSite fields: '$table' loaded";
	        }
	        else {
                  DLog::log("insert FAILED");
                  $response['--msg'] = "XbuildSite fields: '$table' loading failed !";
	        }
              }

	      /* 'XbuildSite__tables */
	      $insert = "INSERT INTO `XbuildSite__tables`";
	      $insert = $insert . " (`site`, `tableName`) values ( ";
	      $insert = $insert . "'$site', '" . $table . "');";
              DLog::log("\$insert: $insert");
              $ires = xf_db_query($insert, $app->db());
              if ($ires) {
                DLog::log("insert OK");
                $response['--msg'] = "XbuildSite table: '$table' loaded";
	      }
	      else {
                DLog::log("insert FAILED");
                $response['--msg'] = "XbuildSite table: '$table' loading failed !";
	      }

	      /* 'XbuildSile__sites */
	      /*
	      $insert = "INSERT INTO `XbuildSite__sites`";
	      $insert = $insert . " (`site`) values ( ";
	      $insert = $insert . "'$site');";
              DLog::log("\$insert: $insert");
              $ires = xf_db_query($insert, $app->db());
              if ($ires) {
                DLog::log("insert OK");
                $response['--msg'] = "XbuildSite sites: '$table' loaded";
	      }
	      else {
                DLog::log("insert FAILED");
                $response['--msg'] = "XbuildSite sites: '$table' loading failed !";
	      }
	      */

	      /* 'XbuildSite__userinfo */
	      $insert = "UPDATE `XbuildSite__userinfo` set `currTable` = '" . $table .
		        "' where `userName` = 'xAdmin'";
              DLog::log("\$insert: $insert");
              $ires = xf_db_query($insert, $app->db());
              if ($ires) {
                DLog::log("insert OK");
                $response['--msg'] = "XbuildSite sites: '$table' loaded";
	      }
	      else {
                DLog::log("insert FAILED");
                $response['--msg'] = "XbuildSite sites: '$table' loading failed !";
	      }
            }
          }
	  break;
  
        case "Delete":
          DLog::log("got 'Delete' Database table");
          die("got 'Delete' Database table");
          $num = xbuild__getRowNum($app, $table, $site);
	  if ($num == 0) {
            $response['--msg'] = "XbuildSite delete failed - no table loaded !";
	  } else {
            /* xBuildSite__fields */
            $query = "delete from `xBuildSite__fields` where `tableName` = '" . $table . "'";
            DLog::log("\$query: $query");
  
            $res = xf_db_query($query, $app->db());
            if ($res) {
              DLog::log("OK: $res");
              $response['--msg'] = "XbuildSite description for: '$table' deleted";
	    }
	    else {
              DLog::log("Failed: $res");
              $response['--msg'] = "XbuildSite delete description for: '$table' failed !";
	    }

            /* xBuildSite__tables */
            $query = "delete from `xBuildSite__tables` where `tableName` = '" . $table . "'";
            DLog::log("\$query: $query");
  
            $res = xf_db_query($query, $app->db());
            if ($res) {
              DLog::log("OK: $res");
              $response['--msg'] = "XbuildSite description for: '$table' deleted";
	    }
	    else {
              DLog::log("Failed: $res");
              $response['--msg'] = "XbuildSite delete description for: '$table' failed !";
	    }

            /* xBuildSite__sites */
            $query = "delete from `xBuildSite__sites` where `site` = '" . $site . "'";
            DLog::log("\$query: $query");
  
            $res = xf_db_query($query, $app->db());
            if ($res) {
              DLog::log("OK: $res");
              $response['--msg'] = "XbuildSite description for: '$site' deleted";
	    }
	    else {
              DLog::log("Failed: $res");
              $response['--msg'] = "XbuildSite delete description for: '$site' failed !";
	    }
	  }
	  break;
  
        case "Write":
	  $discName =  $_POST['xbuild__site'];
	  $title = "";
	  $auth = "";
          DLog::log("got 'Write' discName: '" . $discName . "', site: '$site', table: '$table'");
          $num = xbuild__getRowNum($app, $table, $site);
	  if ($num == 0) {
            $response['--msg'] = "XbuildSite write failed - table '$table' not loaded !";
	  } else {
	    // $site = $_POST['xbuild__site'];
            $select = "SELECT title, auth, path, heading FROM xBuildSite__sites where `site` = '$site'";
	    DLog::log("\$select: $select");
            $res = xf_db_query($select, $app->db());
	    if ($res) {
              $row = xf_db_fetch_array($res, MYSQL_BOTH);
	      DLog::log(">> select: $row[0], $row[1]");
	      $title = $row[0];
	      $auth = $row[1];
	      $path = $row['path'];
	      $htmlHead = $row['heading'];
	      DLog::log(">> title: '$title', auth: '$auth', discName: '$discName', path: '$path'");
	      if ($path != "")
		$discName = "$path/$discName";
	      DLog::log(">> title: '$title', auth: '$auth', discName: '$discName', path: '$path'");
	      $a = explode("/", "xx"); DLog::log("count(): " .  count($a));
	      $a = explode("/", "../"); DLog::log("count(): " .  count($a));
	      $a = explode("/", ""); DLog::log("count(): " .  count($a));
	      // return;
	    }
	    else
	      die("select title, auth FAILED ! ");

            $update = "UPDATE xBuildSite__sites set `discName` = '" . $_POST['xbuild__site'] . "' where `site` = '$site'";
	    DLog::log("\$update: $update");
            $res = xf_db_query($update, $app->db());
	    $dir = dirname(__FILE__) . "/../$discName";

	    DLog::log("Creating directory: '$site', dirname:" . dirname(__FILE__));
	    if (! file_exists($dir)) {
	      DLog::log("! dir_exists");
              mkdir($dir, 0777, true);
            }
	    else
	      DLog::log("dir_exists");

            /* 'conf.ini' file */
	    $conf = fopen($dir."/conf.ini",'w') or die("fopen(".$dir."/conf.ini)") ;
            fwrite($conf, ";;Configuration settings for application '$site'\n" .
		 "title=\"$title\"\n" .
		 "default_browse_action=edit\n" .
                 "default_limit=20\n\n" .
                 "[_database]\n" .
                 "  driver=\"" . $app->_conf['_database']['driver'] . "\"\n" .
                 "  host=\"" . $app->_conf['_database']['host'] . "\"\n" .
                 "  name=\"" . $app->_conf['_database']['name'] . "\"\n" .
                 "  user=\"" . $app->_conf['_database']['user'] . "\"\n" .
                 "  password=\"" . $app->_conf['_database']['password'] . "\"\n\n" .
                 "[_auth]\n" .
		 "  ;Authentication: \"$auth\"\n" .
                 "  users_table = xBuildSite__users\n" .
                 "  username_column = userName\n" .
                 "  password_column = password\n\n" .
		 "[_disallowed_tables]\n" .
                 ";  rule_1 = \"/^xBuildSite__/\"\n\n" .
	         "[_tables]\n");
                 // ";allow_register=1\n\n" .
	         // "$table = \"$table\"\n");
	    // fclose($file);

            /* '.htaccess' file */
	    $file = fopen($dir."/.htaccess",'w') or die("fopen(".$dir."/.htaccess)") ;
            fwrite($file, "<FilesMatch \"\\.ini$\">\n" .
                 "Deny from all\n" .
                 "</FilesMatch>");
	    fclose($file);

	    /* 'index.php' file */
	    $file = fopen($dir."/index.php",'w') or die("fopen(".$dir."/index.php)") ;
	    fwrite($file, "<?php\n" .
		 "//'index.php' file for application '$site'\n" .
                 "/**\n" .
                 "* File: index.php\n" .
                 "* Description:\n" .
                 "* -------------\n" .
                 "*\n" .
                 "* This is an entry file for this Dataface Application.  To use your application\n" .
                 "* simply point your web browser to this file.\n" .
                 "*/\n" .
                 "\$time = microtime(true);\n" .
                 "// use the timer to time how long it takes to generate a page\n\n" .
		 "// Does the 'xbSettings.php' file exist ?\n" .
		 "\$filename = '../xbSettings.php';\n" .
		 "if (! file_exists(\$filename))\n" .
                 "  die(\"'xbSettings.php' does not exist in parrent folder. Please correct this\");\n\n" .
		 "require_once '../xbSettings.php';\n\n" .
		 "// the public interface to xataface\n" .
		 "require_once \"\$xatafacePath/\$xataface/dataface-public-api.php\";\n\n" .
                 // "require_once '/xampp/htdocs/xataface/dataface-public-api.php';\n" .
	         "// include the initialization file\n" .
		 "df_init(__FILE__, \"../\$xatafaceRelative\");\n" .
                 // "df_init(__FILE__, '../xataface');\n" .
	         "// initialize the site\n" .
                 "\n" .
                 "\$app =& Dataface_Application::getInstance();\n" .
	         "  // get an application instance and perform initialization\n" .
                 "\$app->display();\n" .
	         "  // display the application\n\n" .
                 "\$time = microtime(true) - \$time;\n" .
		 "echo \"Execution Time: \$time\";\n"); // "? >\n");
	    fclose($file);

	    /* Directories: */
	    $dirs = array("conf", "js", "css", "tables", "templates", "templates_c");
            foreach ($dirs as $value) {
	      $dir = dirname(__FILE__) . "/../$discName/$value";
	      DLog::log("Creating directory: '$value', dirname:" . dirname(__FILE__));
	      if (! file_exists($dir)) {
	        DLog::log("! dir_exists: $dir");
                mkdir($dir, 0777, true);
              }
	      else
	        DLog::log("dir_exists: $dir");
            }
            /* The 'ApplicationDelegate.php' file */
	    $appDele = fopen(dirname(__FILE__) . "/../$discName/conf/ApplicationDelegate.php",'w') or
		              die("fopen(dirname(__FILE__)" . "/../$discName/conf/ApplicationDelegate.php)");

            $roleLine = ($auth == "noAuth" ? "ADMIN" : "READ ONLY");
	    // $roleLine = "  static \$role = " . ($auth == "noAuth" ? "READ ONLY" ? "none");
            fwrite($appDele, "<?php\n" .
                             "// 'ApplicationDelegate.php' file automatically generated by XbuildSite\n" .
			     // "require_once \"../xBuildSite/log.php\";\n" .
                             "class conf_ApplicationDelegate {\n" .
			     "  static \$role = '$roleLine';\n\n" .
                             "  function block__custom_javascripts(){\n" .
                             "    echo '<script src=\"js/javascripts.js\" type=\"text/javascript\" language=\"javascript\"></script>';\n" .
                             "  }\n\n");
            fwrite($appDele, "  function beforeHandleRequest() {\n" .
                             "    \$app =& Dataface_Application::getInstance();\n" .
                             "    \$app->addHeadContent('<link rel=\"stylesheet\" type=\"text/css\" href=\"css/globals.css\"/>');\n" .
                             "  }\n\n");
 
	    switch ($auth) {
	    case "noAuth": 
                 fwrite($appDele, "  function getRoles(&\$record) {\n" .
                                  "    return self::\$role;\n" .
                                  "  }\n\n");
	         break;

	    case "xfAuth":
                 fwrite($appDele, "  function getRoles(&\$record) {\n" .
			          "    \$auth =& Dataface_AuthenticationTool::getInstance();\n" .
                                  "    \$user =& \$auth->getLoggedInUser();\n" .
                                  "    if (isset(\$user)) {\n" .
                                  "      DLog::log(\"self:: \" .  self::\$role . \"user: \" . \$user->val('role'));\n" .
                                  "      self::\$role = \$user->val('role');\n" .
                                  "      return  \$user->val('role');\n" .
                                  "    }\n" .
                                  "    else {\n" .
                                  "      if (self::\$role == null) {\n" .
                                  "        DLog::log(\"null self:: \" .  self::\$role);\n" .
	                          "        self::\$role = 'READ ONLY';  // Not loggged in\n" .
	                          "        // self::\$role = 'NO ACCESS';  // Not loggged in\n" .
                                  "      }\n" .
                                  "      else {\n" .
                                  "        DLog::log(\"NOT null self:: \" .  self::\$role);\n" .
                                  "      }\n" .
                                  "    }\n" .
				  "    return self::\$role;\n" . 
                                  "  }\n\n");
                 fwrite($appDele, "  function after_action_login() {\n" .
                                  "    DLog::log(\"after_action_login()\");\n" .
                                  "    \$app =& Dataface_Application::getInstance();\n" .
                                  "    \$auth =& Dataface_AuthenticationTool::getInstance();\n" .
                                  "    \$user =& \$auth->getLoggedInUser();\n" .
                                  "    \$uname = \$user->val('userName');\n" .
				  "    self::\$role =  \$user->val('role');\n" .
                                  "    DLog::log(\"role: \" . \$user->val('role') . \", self:: \" .  self::\$role);\n\n" .
                                  "    DLog::log(\"user: \" . \$uname . \", dir: \" . __DIR__ . \", file: \" . __FILE__);\n" .
                                  "    DLog::log(\"title: \" . \$app->getSiteTitle());\n" .
                                  "    \$query = \"select auth from `xBuildSite__site` where `userName` = '\$uname'\";\n" .
                                  "    \$query = \"select userId from `xBuildSite__users` where `userName` = '\$uname'\";\n" .
                                  "    DLog::log(\"query: \$query\");\n" .
                                  "    \$res = xf_db_query(\$query, \$app->db());\n" .
                                  "    if (\$res) {\n" .
                                  "      \$row = xf_db_fetch_array(\$res, MYSQL_NUM);\n" .
                                  "      \$num = \$row[0];\n" .
                                  "      DLog::log(\"num: \$num\");\n" .
                                  "    }\n" .
                                  "    else\n" .
                                  "      DLog::log(\"FAILED !!\");\n" .
                                  "  }\n");
	         break;

	       default:
	         die("Unknown \$auth: '$auth'");
	         break;
                     
	    }
               fwrite($appDele, "  function block__before_header() {\n" .
		                "    echo '$htmlHead';\n" .
                                "  }\n");

            /* The 'js/javascripts.js' file */
	    $css = fopen(dirname(__FILE__) . "/../$discName/css/globals.css",'w') or
		              die("fopen(dirname(__FILE__)" . "/../$discName/css/globals.css)") ;

            /* The 'js/javascripts.js' file */
	    $js = fopen(dirname(__FILE__) . "/../$discName/js/javascripts.js",'w') or
		              die("fopen(dirname(__FILE__)" . "/../$discName/js/javascripts.js)") ;
	    fwrite($js, "//require <jquery.packed.js>\n" .
                        "//require <xatajax.form.core.js>\n" .
                        "//require <ckeditor.js>\n\n" .
                        "function xbuild__nullGroup(name, str, arr) {\n" .
                        "  var index, text = \"==\";\n" .
                        "  for (index = 0; index < arr.length; index++) {\n" .
                        "    text += arr[index] + \", \";\n" .
                        "    if (arr[index] != str)\n" .
                        "      document.getElementById(arr[index]).value = '';\n" .
                        "  }\n" .
                        // "  confirm(\"Happy birthday, \" + name + \"!!!\\n\" + str + \"=>\" + text);\n" .
                        "}\n");

            fclose($js);

	    /* The 'tables' sub directories */
            $query = "select distinct tableName from xBuildSite__fields where site = '$site'";
            $tableres = xf_db_query($query, $app->db());
	    /*
	    $tables = array();
	    $nr = 0;
            if ($res) {
              while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
		$tables[$nr++] = $row[0];
	      }
	    }

            foreach ($tables as $value) {
	     */
	    DLog::log("\$query: $query");
	    $tableList = "";
            if ($tableres) 
            while ($tablerow = xf_db_fetch_array($tableres, MYSQL_BOTH)) {
	      $value = $tablerow[0];
	      $table = $tablerow[0];
	      $tableList[] =  $table;
	      DLog::log("::: table: " . $table);

	      /* Add a line to 'conf.ini' for eack table */
              $query = "select name from `xBuildSite__tables` where `site` = '$site' and `tableName`= '$table'";
              $tableSite = xf_db_query($query, $app->db());
              DLog::log("+++ \$query: $query");
	      $tblName = $table;
              if ($tableSite) {
                DLog::log("+++ \$tableSite: $query");
                $tableName = xf_db_fetch_array($tableSite, MYSQL_BOTH);
		if ($tableName) {
                  DLog::log("+++ ok !!");
                  DLog::log("+++ \$tableSite: $tableName[0]");
		  $tblName = $tableName[0];
		}
		else
                  DLog::log("+++ Failed !!");
	      }
              fwrite($conf, "  $table = \"$tblName\"\n");
              // fwrite($conf, "$value = \"$value\"\n");

	      $dir = dirname(__FILE__) . "/../$discName/tables/$value";
	      DLog::log("Creating sub directory: '$value', dirname:" . dirname(__FILE__));
	      if (! file_exists($dir)) {
	        DLog::log("! dir_exists: $dir");
                mkdir($dir, 0777, true);
              }
	      else
	        DLog::log("dir_exists: $dir");

              /* The 'fields.ini' file */
              $query = "select * from `xBuildSite__fields` where `site` = '$site' and `tableName`= '$table'";
              DLog::log("\$query: $query");
    
              $res = xf_db_query($query, $app->db());
              if ($res) {
		$nullGrpArray = array();
		DLog::Log("=====");
                $query = "select `columnName`, `nullGrp` from `xBuildSite__fields` where `site` = '$site' and `tableName`= '$table' and nullGrp != ''";
                $nullGrp = xf_db_query($query, $app->db());
                if ($nullGrp) {
                  while ($null = xf_db_fetch_array($nullGrp, MYSQL_BOTH)) {
		    DLog::Log("col: " . $null[0] . ", nullGrp: " . $null[1]);
		    if (isset($nullGrpArray[$null[1]]))
		      $nullGrpArray[$null[1]] =  "\\\"" . $null[0] . "\\\"" . ", " . $nullGrpArray[$null[1]];
		    else
		      $nullGrpArray[$null[1]] = "\\\"" . $null[0] . "\\\"";
		  }
                  foreach($nullGrpArray as $x=>$x_value) {
		    DLog::Log("Key=" . $x . ", Value=" . $x_value);
		    $nullGrpArray[$x] = "[" . $nullGrpArray[$x] . "]";
                  }
                  foreach($nullGrpArray as $x=>$x_value)
		    DLog::Log("Key=" . $x . ", Value=" . $x_value);
		}
		DLog::Log("=====");

		/* The 'fields.ini' file */
	        $file = fopen($dir."/fields.ini",'w') or die("fopen(".$dir."/fields.ini)") ;
                fwrite($file, ";; 'fields.ini' file automatically generated by XbuildSite\n");

		/* The 'valuelists.ini' file */
	        $vlist = fopen($dir."/valuelists.ini",'w') or die("fopen(".$dir."/valuelists.ini)") ;
                fwrite($vlist, ";; 'valuelists.ini' file automatically generated by XbuildSite\n");

		/* The delegate class '<table>.php' file */
	        $dlist = fopen("$dir/$table.php",'w') or die("fopen(".$dir."/$table.ini)") ;
		fwrite($dlist, "<?php\n" .
			       "// '$table.php' <table> delegate class file automatically generated by XbuildSite\n" .
                               "class tables_$table {\n");

                while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
                  // DLog::log("column:" . $row['columnName']);

                  fwrite($file, "[" . $row['columnName'] . "]\n");
		  if ($row['vis'] == "Hidden")
                    fwrite($file, "  visibility:list = hidden\n  visibility:browse = hidden\n  widget:type = hidden\n");
		  if ($row['vis'] == "Not editable") {
                    fwrite($dlist, "  function " . $row['columnName'] . "__permissions(\$record) {\n" .
                                  "    return array('edit'=>0, 'new'=>0);\n  }\n");
		  }

		  if ($row['vis'] == "Required") {
		    fwrite($file, "  validators:required = true\n" .
			    "  validators:required:message = \"Field '" .
			    (isset($row['label']) ? $row['label'] : $row['columnName']) . "' is required\"\n");
		  }
		  if ($row['label'])
                    fwrite($file, "  widget:label = \"" . $row['label'] . "\"\n");
		  if ($row['description'])
                    fwrite($file, "  widget:description = \"" . $row['description'] . "\"\n");

		  if ($row['validate']) {
	            DLog::log("validate: " .  $row['validate']);
		    $args = explode(";", $row['validate']);
	            DLog::log("count(): " .  count($args));
		    if (count($args) == 2) {
		      fwrite($file, "  validators:regex = \"/^" . $args[0] . "$/\"\n");
                      fwrite($file, "  validators:regex:message = \"" . $args[1] . "\"\n");
		    }
		    /*

		    fwrite($file, "  validators:regex = \"/^" . $row['validate'] . "$/\"\n");
		    if ($row['message'])
                      fwrite($file, "  validators:regex:message = \"" . $row['message'] . "\"\n");
		    else
	  	      fwrite($file, "  validators:regex:message = \"Please enter a valid input, RegEx: '"
		      . $row['validate'] . "'\"\n");
		     */
		  }

		  if ($row['type']) {
		    DLog::log("type: " . $row['type']);
		    switch ($row['type']) {
		      case "checkbox":
		           fwrite($file, "  widget:type = checkbox\n");
			   fwrite($dlist, "  function " . $row['columnName'] . "__renderCell(&\$record) {\n" .
                                          "    if (\$record->strval('" . $row['columnName'] . "') == 1)\n" .
                                          "      \$check = \"checked\";\n" .
                                          "    else\n" .
                                          "      \$check = \"\";\n" .
                                          "    return '<input type=checkbox ' . \$check . '  disabled>';\n" .
                                          "  }\n\n");
			   break;

		      case "www":
			   DLog::log("www");
			   fwrite($dlist, "  function " . $row['columnName'] . "__renderCell(&\$record) {\n" .
				          "    \$www = \$record->strval('" . $row['columnName'] . "');\n" .
                                          "    return \"</a><a href=http://\$www style='color:blue;'>\$www\";\n" .
                                          "  }\n\n");
				        
			   break;

		      case "email":
			   DLog::log("email");
			   fwrite($dlist, "  function " . $row['columnName'] . "__renderCell(&\$record) {\n" .
				          "    \$email = \$record->strval('" . $row['columnName'] . "');\n" .
                                          "    return \"</a><a href='mailto:\$email' style='color:blue;'>\$email\";\n" .
                                          "  }\n\n");
				        
			   break;

			   /*
			   fwrite($dlist, "  function " . $row['columnName'] . "__renderCell(&\$record) {\n" ;
                                           // "    if (\$record->strval('check') == 1)\n" .
                                           // "    return 'hej <a href=\"http://www.w3schools.com/html/\">Visit</a>';\n" .
                                           // "  }\n\n");
			   break;
			    */
		    }
		  }

		  if ($row['nullGrp'] != '')  {
		    fwrite($file, "  widget:atts:onchange=\"xbuild__nullGroup(this.value, '" . $row['columnName'] .
		                     "', " . $nullGrpArray[$row['nullGrp']] . ");\"\n");
		    fwrite($file, "  group = \"" . $row['nullGrp'] . "\"\n");
		  }
		  // $nullGrpArray[$null[1]]
		  /* select lists */
		  if ($row['text'] != "") {
	            DLog::log("text: " .  $row['text']);
		    $args = explode(";", $row['text']);
	            DLog::log("count(): " .  count($args));
		    switch ($args[0]) {
		      case "Select":
		           if (count($args) == 4) {
			     $id =  explode("[", $args[2]);
			     $name =  explode("[", $args[3]);
			     DLog::log("id: " . $id[0] . ", name: " . $name[0]);
		             fwrite($file, "  widget:type = select\n" .
		                "  vocabulary = list-" . $row['columnName'] . "\n");
		             fwrite($vlist, "[list-" . $row['columnName'] . "]\n" .
		                "  __sql__ = \"SELECT " . $id[0] . ", " . $name[0] .
		                " FROM " . $args[1] . "\"\n\n");
			     fwrite($css, "#" . $row['columnName'] . "-other {\n    display: none;\n}\n");
		           }
		           break;
		    }
		  }
		  /*
		  if ($row['o2o_table'] AND $row['o2o_id'] AND $row['o2o_field']) {
		    fwrite($file, "  widget:type = select\n" .
		       "  vocabulary = list-" . $row['columnName'] . "\n"); // $row['o2o_table'] . "\"\n");
		    fwrite($vlist, "[list-" . $row['columnName'] . "]\n" .
		    "  __sql__ = \"SELECT " . $row['o2o_id'] . ", " . $row['o2o_field'] .
		    " FROM " . $row['o2o_table'] . "\"\n\n");
		  }
		   */

                  fwrite($file, "\n");
                }
		/* Import filter */
		  DLog::log("----------");
                  $query = "select `columnName` from `xBuildSite__fields` where `site` = '$site' and `tableName`= '$table'";
                  DLog::log(">>\$query: $query");
                  $tblres = xf_db_query($query, $app->db());
		  $nr = 0;
		  $str = '';
		  $tblList = array();
                  if ($tblres) {
                    DLog::log(">>OK");
                    while ($row = xf_db_fetch_array($tblres, MYSQL_BOTH)) {
                      // DLog::log(">>column:" . $row['columnName']);
		      $str =  $nr == 0 ?  "\$" . $row['columnName'] : $str . ", \$" .  $row['columnName'];
		      $tblList[$nr++] =  $row['columnName'];
		    }
		    // $str = substr(0, strlen($str)-1);
		  }
		  else
                    DLog::log(">>FAILED !!");

                  fwrite($dlist, "  function __import__csv(&\$data, \$defaultValues=array()) {\n" .
                                 "    // build an array of Dataface_Record objects that are to be inserted based\n" .
                                 "    // on the CSV file data.\n" .
                                 "    \$records = array();\n" .
                                 "    // first split the CSV file into an array of rows.\n" .
                                 "    \$rows = explode(\"\\n\", \$data);\n" .
                                 "    foreach (\$rows as \$row ) {\n" .
                                 "      // We iterate through the rows and parse the fields\n" .
                                 "      // addresses to that they can be stored in a Dataface_Record object.\n" .
                                 "      // list(\$id, \$postNr, \$byNavn) = explode(',', \$row);\n" .
				 "      list(" . $str . ") = explode(',', \$row);\n" .
                                 "      \$record = new Dataface_Record('$table', array());\n" .
                                 "      // We insert the default values for the record.\n" .
                                 "      \$record->setValues(\$defaultValues);\n" .
                                 "      // Now we add the values from the CSV file.\n" .
                                 "      \$record->setValues(\n" .
				 "        array(\n");

	 	  foreach ($tblList as $value) {
                      fwrite($dlist, "          '" . $value . "' => \$" . $value . ",\n");
		  }
		  /*
                  $query = "select `columnName` from `xBuildSite__fields` where `site` = '$site' and `tableName`= '$table'";
                  DLog::log(">>\$query: $query");
                  $tblres = xf_db_query($query, $app->db());
                  if ($tblres) {
                    DLog::log(">>OK");
                    while ($row = xf_db_fetch_array($tblres, MYSQL_BOTH)) {
                      DLog::log(">>column:" . $row['columnName']);
                      fwrite($dlist, "          '" . $row['columnName'] . "' => \$" . $row['columnName'] . ",\n");
		    }
		  }
		  else
                    DLog::log(">>FAILED !!");
				 /*
                                 "          'postNr' => \$postNr,\n" .
                                 "          'byNavn' => \$byNavn\n" .
				  */
                  fwrite($dlist, "        )\n" .
                                 "      );\n" .
                                 "      // Now add the record to the output array.\n" .
                                 "      \$records[] = \$record;\n" .
                                 "    }\n" .
                                 "    // Now we return the array of records to be imported.\n" .
                                 "    return \$records;\n");

                  fwrite($dlist, "  }\n\n");

		/* Handle the 'nullGrp' fieldgroup's */
		$order = 1;
                foreach($nullGrpArray as $x=>$x_value) 
		  // DLog::Log("Key=" . $x . ", Value=" . $x_value);
                  fwrite($file, "[fieldgroup:\"" . $x . "\"]\n" .
                                "  description = \"Changing the value of one field below will cause the other fields to be cleared\"\n" .
                                "  collapsed=0\n" .
                                "  order = " . $order++ . "\n\n");

	        fclose($file);
	        fclose($vlist);
		fwrite($dlist, "}\n");
	        fclose($dlist);
	      }
            }
	    /* Write allowed/disallowed tables */
            fwrite($conf, "\n[_disallowed_tables]\n  rule_0 = \"/[a-zA-Z0-9]+/\"\n");
            fwrite($conf, "\n[_allowed_tables]\n");
	    $nr = 0;
 	    foreach ($tableList as $value) {
              fwrite($conf, "  rule_" . ++$nr . " = " . $value . "\n");
	    }

	    fclose($conf);
            fwrite($appDele, "}\n");
	    fclose($appDele);
	    fclose($css);

            $response['--msg'] = "Xataface site: '$discName' created";
	  }

	  break;

        case "Try it":
          DLog::log("Try it, \$POST['__xbuild']: ". $_POST['__xbuild']);
	  DLog::log(dirname(__FILE__) . "/../$site/index.php");
	  include dirname(__FILE__) . "/../$site/index.php";
	  break;

        default:
          DLog::log("default, \$POST['__xbuild']: ". $_POST['__xbuild']);
	  break;
      }
    }
  }
?>
