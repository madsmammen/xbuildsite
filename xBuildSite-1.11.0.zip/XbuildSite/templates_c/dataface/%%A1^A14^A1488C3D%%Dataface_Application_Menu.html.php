<?php /* Smarty version 2.6.18, created on 2015-04-27 11:13:53
         compiled from Dataface_Application_Menu.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'actions_menu', 'Dataface_Application_Menu.html', 20, false),)), $this); ?>
<?php echo $this->_plugins['function']['actions_menu'][0][0]->actions_menu(array('category' => 'main_menu','class' => 'main_menu'), $this);?>