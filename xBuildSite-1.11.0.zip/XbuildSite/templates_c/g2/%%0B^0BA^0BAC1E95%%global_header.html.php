<?php /* Smarty version 2.6.18, created on 2015-04-27 11:13:53
         compiled from global_header.html */ ?>
