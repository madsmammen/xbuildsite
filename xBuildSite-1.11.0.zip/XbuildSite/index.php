<?php
/**
 * File: index.php
 * Description:
 * -------------
 *
 * This is an entry file for this Dataface Application.  To use your application
 * simply point your web browser to this file.
 */
  $time = microtime(true);

  require 'kint-0.9/Kint.class.php';
  // require_once '/xampp/htdocs/mssql/mswrap.php';
  require_once 'log.php';
  

  DLog::log("Index.php");
  // echo 'My username is ' . $_ENV["HOSTNAME"] . '!';

  require_once '../xbSettings.php';

  // use the timer to time how long it takes to generate a page

  require_once "$xatafacePath/$xataface/dataface-public-api.php";
  // require_once '/xampp/htdocs/xataface/dataface-public-api.php';
 
  // include the initialization file
  df_init(__FILE__, "../$xatafaceRelative");

  // initialize the site

  $app =& Dataface_Application::getInstance();
  // get an application instance and perform initialization
 
  if (false) {
    if (isset($_SESSION)) {
      DLog::log("_SESSION ===: " . count($_SESSION));
      if (count($_SESSION) > 0)
        foreach ($_SESSION as $value) {
          DLog::log("  _SESSION: '$value'");
        }
    }
    if (isset($_REQUEST)) {
      DLog::log("_REQUEST ===: " . count($_REQUEST));
      if (count($_REQUEST) > 0)
        foreach ($_REQUEST as $value) {
          DLog::log("  _REQUEST: '$value'");
        }
    }
    if (isset($_POST)) {
      DLog::log("_POST ===: " . count($_POST));
      if (count($_POST) > 0)
        foreach ($_POST as $value) {
          DLog::log("  _POST: '$value'");
        }
    }
    if (isset($_GET)) {
      DLog::log("_GET ===: " . count($_GET));
      if (count($_GET) > 0)
        foreach ($_GET as $value) {
          DLog::log("  _GET: '$value'");
        }
    }
  }

  if (isset($_POST)) {
    DLog::log("isset(\$_POST)");
    foreach($_POST as $x=>$x_value) {
      DLog::Log("Key=" . $x . ", Value=" . $x_value);
    }
    if (isset($_POST['__xbuild']) || isset($_POST['selectSite']))
      require_once 'xbuild.php';
  }

  $app->display();
	// display the application
  
  echo "\$_REQUEST:";
  print_r($_REQUEST);
  echo "<br>\$_GET:";
  print_r($_GET);
  echo "<br>\$_POST:";
  print_r($_POST);

  $time = microtime(true) - $time;
  echo "<br>Execution Time: $time";
?>
