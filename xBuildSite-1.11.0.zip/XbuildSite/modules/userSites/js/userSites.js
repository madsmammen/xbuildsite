//require <jquery.packed.js>

var $ = jQuery;
x = 0;

// Change the selector if needed
var $table = $('table.scroll'),
    $bodyCells = $table.find('tbody tr:first').children(),
    colWidth;

// Adjust the width of thead cells when window resizes
$(window).resize(function() {
    // console.log("resize");
    // Get the tbody columns width array
    colWidth = $bodyCells.map(function() {
        return $(this).width();
    }).get();
    
    // Set the width of thead columns
    $table.find('thead tr').children().each(function(i, v) {
        $(v).width(colWidth[i]);
    });    
    console.log("userSites::resize.js");
}).resize(); // Trigger resize handler

(function(){
    var $ = jQuery;
    $(document).ready(function(){
        $('#xb__userSitesSelect').click(function(){
            // The selected value: $('#xb__userSitesSelect').val()
	    console.log("xb__userSitesSelect: " + $('#xb__userSitesSelect').val());
        });
    });
})();

function df_addNew(target,formel){

		formUrl = '?-action=ajax_form&-form-type=new&-fields='+escape(fieldnames)+'&-table='+escape(table)+'&-target-id='+escape(targetid);
}



function xb__() {
  var i, innerHtml = "";

  console.log("xb__adGroupOnload()");
}
