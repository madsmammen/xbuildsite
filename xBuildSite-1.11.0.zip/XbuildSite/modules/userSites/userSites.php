<?php
/*
class group_ele {
  var $group;
  var $role;
  var $use = 0;
};
 */

class modules_userSites {

  static $groups = array("hej");
  

  function modules_userSite() {
    DLog::log("modules_userSite()");
    $app =& Dataface_Application::getInstance();
    print_r($_POST);
    print_r($_GET);
    /*
    $query = "select * from xBuildSite__groups";
    DLog::log("query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
      $nr = 0;
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
	DLog::log($nr . ": groupName: " . $row['groupName'] . ", access: " . $row['access']);
	$ele = new group_ele;
	$ele->group = $row['groupName'];
	$ele->role = $row['access'];
	// self::$groups[$nr++] = $row['groupName'];
        self::$groups[$nr++] = $ele;
      }
      DLog::log("modules_appGroups() count: " . count(self::$groups));
      xf_db_free_result($res);
    }
    else {
      DLog::log("modules_appGroups(): query FAILED !!");
    }
     */
  }

  function block__userSites_select() {
    $app =& Dataface_Application::getInstance();
    $query = "select * from xBuildSite__users";
    DLog::log("query: $query");
    $res = xf_db_query($query, $app->db());
    $nr = 0;
    echo "<option>Please Select..</option>";
    if ($res) {
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
	$nr++;
        echo "<option>" . $row['userName'] . "</option>";
      }
    }
    xf_db_free_result($res);
  }

  function block__userSites_main() {
    DLog::log ("modules_userSite::block__main()" . self::$groups);
    $app =& Dataface_Application::getInstance();
    // $auth =& Dataface_AuthenticationTool::getInstance();
    // $creds = $auth->getCredentials();

    $query = "select * from xBuildSite__sites";
    DLog::log("query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
         echo "<thead><tr><th>Site</th><th>App. group</th><th>X</th><th>Access</th></tr></thead>";
	 echo "<tbody style='height:150px;'>";

      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
        echo "<tr><td><b>" . $row['site'] . "</b></td><td>&nbsp</td><td>&nbsp</td>&nbsp<td>&nbsp</td></tr>";
	DLog::log("authGrp: '" . $row['authGrp'] . "'");
	$arr = explode(chr(10), $row['authGrp']);
	DLog::log("explode: " . count($arr));
	if ($arr[0] != '') {
	  for ($i=0; $i < count($arr); $i++) {
	    echo "<tr><td>&nbsp</td><td width=95%>" . $arr[$i] .
		  "</td><td style='_min-width:25px;'><img src='modules/userSites/images/s_success.png' _alt='m'></td><td style='min-width:60px;'>" . self::getRole($arr[$i]) . "</td></tr>";
	  }
        }
      }
      echo "</tbody>";
      xf_db_free_result($res);
    }
    else {
      DLog::log("block__appGroups_main(): query FAILED !!");
    }
  }

  function block__userSite_notUsed() {

    echo "<thead><tr><th></th><th>App. group</th><th>use count</th><th>&nbsp&nbsp</th></tr></thead>";
    echo "<tbody height=100px>";
    for($i=0; $i < count(self::$groups); $i++) {
      $ele = self::$groups[$i];
      if ($ele->use == 0) {
	echo "<tr><td></td><td>$ele->group</td><td>$ele->use</td></tr>";
      }
    }
    echo "</tbody>";
    // $app->redirect($values['--query']);

    $app = Dataface_Application::getInstance();

    if ( class_exists('Dataface_AuthenticationTool')) {
      $auth = Dataface_AuthenticationTool::getInstance();
      if ($auth->isLoggedIn())
        DLog::log("auth:'"); //  . ($auth->isLogedIn() ? "TRUE" : "FALSE") . "'");
      else
        DLog::log("No isLogginIn()");
    }
    else
      DLog::log("No class !!");

    DLog::log("Session: '" . $_SESSION['UserName'] . "'");


  }

  function getRole($grp) {
    // $ele = self::$groups[3];
    // DLog::log("getRole() count: " . $ele->group . count(self::$groups));
    for($i=0; $i < count(self::$groups); $i++) {
      $ele = self::$groups[$i];
      if ($ele->group == $grp) {
	$ele->use++;
        return($ele->role);
      }
    }
    return("Role");
  }

  function xb_is_logged_in(){
    $app = Dataface_Application::getInstance();

    if ( class_exists('Dataface_AuthenticationTool') and
	    ($auth = Dataface_AuthenticationTool::getInstance()) and $auth->isLoggedIn())
      echo $auth->isLogedIn();
  }

}
?>
