<?php

class actions_userSites {
  function handle($params) {
    DLog::log("actions_userSites()");


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    $javascriptTool->addPath(
      dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/userSites/js' // The URL to the js dir
    );
    $javascriptTool->import('userSites.js');
    
    df_register_skin('userSites skin', dirname(__FILE__).'/../');
    df_display(array(), 'userSites_template.html');
  }
}
?>
