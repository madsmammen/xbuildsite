// A closure: An anonymous javascript function, that is called
// immediately after creation.

function xb__adGroupOnload() {
  console.log("xb__adGroupOnload()");
}

