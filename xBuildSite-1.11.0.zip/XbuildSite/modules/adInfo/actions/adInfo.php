<?php

require_once DATAFACE_PATH . "/modules/Auth/adLdap/adLDAP/src/adLDAP.php";


class actions_adInfo {
  function handle($params){
    // echo "<h1>Hello World actions/hello_world.php</h1>"
    DLog::log("actions_adInfo()");

    $auth =& Dataface_AuthenticationTool::getInstance();
    $app =& Dataface_Application::getInstance();
    $creds = $auth->getCredentials();

    DLog::log("func checkCredentials()");

    if (isset($auth))
      DLog::log("isset(\$auth)");
    else
      DLog::log("!isset(\$auth)");

    if (isset($creds))
      DLog::log("isset(\$creds)");
    else
      DLog::log("!isset(\$creds)");

    if (is_array($creds)) {
      // $creds = array("hej" => "mads");
      DLog::log("isarray(\$creds), count: " . count($creds));
      foreach ($creds as $value) {
        DLog::log("creds: $value");
      }
    }
    else
      DLog::log("!isarray(\$creds)");

    DLog::log("handle() << end");


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    $javascriptTool->addPath(
      dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/adInfo/js' // The URL to the js dir
    );
    // $javascriptTool->import('hello_world.js');
    
     
    // df_register_skin('adGroup skin', dirname(__FILE__).'/../templates');
    // df_display(array(), 'adGroup_template.html');

    // df_register_skin('adInfo skin', dirname(__FILE__) . '/../templates');
    df_register_skin('adInfo skin', dirname(__FILE__) .'/../');
    df_display(array(), 'adInfo_template.html');
  }
}
?>
