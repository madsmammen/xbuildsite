<?php
    class AD extends adLDAP {
	    /*
      public void sayHello() {
        System.out.println("Hello");
      }
	     */
    }

class modules_adInfo {
  function modules_adInfo(){
    $app =& Dataface_Application::getInstance();

    echo "Hello modules_adInfo ...";
    echo "xx: " . DATAFACE_SITE_HREF;
    echo "xx: " . df_absolute_url(DATAFACE_SITE_HREF);

    if (isset($app->_conf['_xBuildSite']['site']))
      echo "xx: '" . $app->_conf['_xBuildSite']['site'];
    echo "<br>";
  }

  function _block__before_header(){
    echo "<h1>Hello World ...</h1>";
  }

  function block__main(){
    echo "modules_adInfo::block__main() Main Block...";

    echo "User: " . $_SESSION['user'] . ", passwd: " . $_SESSION['passwd'] . "<br>";
    try {
      $adldap = new adLDAP();
    }
    catch (adLDAPException $e) {
      echo "adLDAPException: " . $e;
      exit();   
    };

    $authUser = $adldap->user()->authenticate($_SESSION['user'], $_SESSION['passwd']);
    // echo $adldap->getLastError();
    if ($authUser) {
      echo "authUser: OK";
      // $user = $adldap->user()->infoCollection($creds['UserName'], array('*'));
      $user =   $adldap->user()->infoCollection('mwbm', array('*'));
      echo "user: OK: " . $user->displayName;

      $username = "mwbm";
      /*
      $userInfo = $adldap->user()->infoCollection($username);
      echo "<br>User: " . $username . ", count(): " . count($userInfo);
      print_r($userInfo);
       */
      echo "<br>";
      $userInfo = $adldap->user()->info($username, array("*"));
      foreach ($userInfo as $key => $val) {
	if (is_array($val)) {
          foreach ($val as $k => $v) 
            echo "<br>== [" . $k . "]: " . $v;
	}
	else
          echo "<br>Info[" . $key . "]: " . $val;
      }

      /*
      echo "<br>Groups:<br>";
      $groupArray = $userInfo->memberOf; 
      foreach ($groupArray as $group) {
       echo $group . "<br>";
      }
       */

      $usernames = $adldap->user()->all(false, "z", true);
      echo "<br>count(): " . count($usernames) . "<br>";

      // $users = array();
      foreach ($usernames as $username) {
        $userInfo = $adldap->user()->infoCollection($username);
        // $users[$username] = $userInfo;
	echo "User: " . $username . "<br>";
      }
    }
    else
      echo "Failed !";

    $adldap->close();
  }
}
?>
