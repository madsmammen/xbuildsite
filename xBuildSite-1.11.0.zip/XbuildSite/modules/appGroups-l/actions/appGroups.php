<?php

class actions_appGroups {
  function handle($params) {
    DLog::log("actions_appGroups::handle()");

    $auth =& Dataface_AuthenticationTool::getInstance();
    $app =& Dataface_Application::getInstance();
    $creds = $auth->getCredentials();


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    $javascriptTool->addPath(
      dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/appGroups/js' // The URL to the js dir
    );
    $javascriptTool->import('appGroups.js');
    // $javascriptTool->import('adGrp.js');

    die( dirname(__FILE__));
    
    df_register_skin('adGroup skin', dirname(__FILE__).'/../templates/');
    df_display(array(), 'adGroup_template.html');
    // df_register_skin('appGroups skin', dirname(__FILE__).'/../templates/');
    // df_display(array(), 'appGroups_template.html');

    $grpArr = self::get_adGroup();
    for ($nr=0; $nr < 8; $nr++) {
      if ($nr == 0)
        $str = "\"" . $grpArr[$nr] . "\"";
      else
        $str = $str . ", \"" . $grpArr[$nr] . "\"";
    }
    $str = "[" . $str . "]";
    DLog::log("str: $str");
    echo "<input size=100 type=text id=xb__adGroupGroups value='" . $str . "'/>";
    echo "<br>url: " . dirname(__FILE__).'/../'.DATAFACE_SITE_URL;

    // Execute the 'xb__adGroupOnload()' function
    echo <<< END
    <script type="text/javascript">
      xb__adGroupOnload();
    </script>
END;

  }

  function get_adGroup() {
  $arr = array(
      "CN=SharefileUser,OU=XenDesktop 7,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=XDM Bruger,OU=XenDesktop 7,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=CTX_Dit_Digitale_Skrivebord,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_Aveleo_Sundhed,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_OS2_Dagsorden,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Genesys_Agent,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=CTX_XenApp_6.5_Dev-Test,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=CTX_XenApp_6.5,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=syddjurs_dk_webmaster,OU=Drupal,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_DNN_Kontraktdatabase,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_ProjektFlow-brugere,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=1_Org_IT_og_Digitalisering_Digitalisering,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_it_nilex,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_Projekt,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_ImportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_Projekt,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_Scripts,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_ExportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SOFD_Dokumentation,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_Dokumentation,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_ExportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_Mifare_Admins,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=P-Skyprinter,OU=print grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_Write_SyddjursDW,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_Scripts,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SEC_Office_Startup_Admins,OU=OfficeSkabeloner,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=SEC_Office_Skabeloner_Admins,OU=OfficeSkabeloner,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_ImportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=DW_Dotnetnuke_Admins,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=P-PR05051,OU=print grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Dpr_Rapport,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Microsoft_Project,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Microsoft_Visio_2010,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_IT_projekt_tools,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Outlook_FreeBusy,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_CtxShadow,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Se_Bruger_Applikationer,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Nilex_Servicedesk,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=1_Lokation_Adm_bygning_Rønde,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=1_Alle,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_CAG_VPN,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Intranet,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_CAG_webmail,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_ACADRE_PROD_SEPWRITE,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Wordpad,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Internet_Explorer,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_lokale_printere,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=TSShadow,CN=Users,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Remote_desktop,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_KOMMUNEKONCEPT,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Powerarchiver,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Adobe_Acrobat_Reader,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Access,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Office_STD,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Stifinder,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_ACADRE_PROD_CM,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_KPS_Blanket,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_TDC_Digital,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=sec_it,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
      "CN=PF_Schultzlovnet,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
      "CN=TSBruger,CN=Users,DC=intern,DC=syddjurs,DC=dk");
    DLog::log("count: " . count($arr));
    
    return($arr);

  }
}
?>
