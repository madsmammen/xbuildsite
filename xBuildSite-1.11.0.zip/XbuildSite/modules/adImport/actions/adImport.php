<?php

require_once DATAFACE_PATH . "/modules/Auth/adLdap/adLDAP/src/adLDAP.php";


class actions_adImport {

  function handle($params) {
    // echo "<h1>Hello World actions/hello_world.php</h1>"
    DLog::log("actions_adImport::handle()");

    if (false) {
    $auth =& Dataface_AuthenticationTool::getInstance();
    $app =& Dataface_Application::getInstance();
    $creds = $auth->getCredentials();

    DLog::log("func checkCredentials()");

    if (isset($auth))
      DLog::log("isset(\$auth)");
    else
      DLog::log("!isset(\$auth)");

    if (isset($creds))
      DLog::log("isset(\$creds)");
    else
      DLog::log("!isset(\$creds)");

    if (is_array($creds)) {
      // $creds = array("hej" => "mads");
      DLog::log("isarray(\$creds), count: " . count($creds));
      foreach ($creds as $value) {
        DLog::log("creds: $value");
      }
    }
    else
      DLog::log("!isarray(\$creds)");
    }

  if (false) {
    $user = $creds['UserName'];
    $user = $auth->getLoggedInUsername(); // & $auth->getLoggedInUser();
    $user =& $auth->getLoggedInUser(); // & $auth->getLoggedInUser();

    $adldap = new adLDAP();
    $user = "mwbm";

    // DLog::log("Uid: " . $user->val('role') . ", password: '");
    // DLog::log("Uid: " . $user . ", password: '");
    // DLog::log("Uid: " . $user . ", password: " . $creds['Password'] . ", val: ");
    // $authUser = $adldap->user()->authenticate($user, $creds['Password']);
    $authUser = $adldap->user()->authenticate($user, 'Mathias3');
    if ($authUser) {
      DLog::log("authUser: OK");
      $user = $adldap->user()->infoCollection($user, array('*'));
      if ($user) {
        DLog::log("info: OK: " . $user->displayName);
	$groupArray = $user->memberOf; 
	if (false) 
        foreach ($groupArray as $group) {
	  // if (preg_match("/sofd/i", $group))	// The "i" after the pattern delimiter indicates a case-insensitive search
  	    DLog::log("group: " . $group);
        }
      }
    }
    else
      DLog::log("authUser: FAILED !!");

    $adldap->close();
  }
    DLog::log("actions_adImport::handle() << end");


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    // $mt = Dataface_ModuleTool::getInstance();
    // $mod = $mt->loadModule('modules_adImport');

    $javascriptTool->addPath(dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/adImport/js' // The URL to the js dir
    );
    $javascriptTool->import('adImport.js');

    $cssTool = Dataface_CSSTool::getInstance();
    $cssTool->addPath(dirname(__FILE__).'/../css',
    	    DATAFACE_SITE_URL.'/modules/adImport/css');


    /*
    $ct = Dataface_CSSTool::getInstance();
    $ct->addPath(dirname(__FILE__).'/../css',  DATAFACE_SITE_URL.'/modules/adImport/css');
    $ct->import('adImport.css');
     */

    
    df_register_skin('adImport skin', dirname(__FILE__).'/../');
    df_display(array(), 'adImport_template.html');

    /*
    $grpArr = self::get_adGroup();
    for ($nr=0; $nr < 8; $nr++) {
      if ($nr == 0)
        $str = "\"" . $grpArr[$nr] . "\"";
      else
        $str = $str . ", \"" . $grpArr[$nr] . "\"";
    }
    $str = "[" . $str . "]";
    DLog::log("str: $str");
    echo "<input size=100 type=text id=xb__adGroupGroups value='" . $str . "'/>";
    echo "<br>url: " . dirname(__FILE__).'/../'.DATAFACE_SITE_URL;
     */ 

    // Execute the 'xb__adGroupOnload()' function
    /*
    echo <<< END
    <script type="text/javascript">
      xb__adGroupOnload();
    </script>
END;
     */
  }

  public function getBaseURL() {
    if (!isset($this->baseURL)) {
      $this->baseURL = Dataface_ModuleTool::getInstance()->getModuleURL(__FILE__);
    }
    return $this->baseURL;
  }
}
?>
