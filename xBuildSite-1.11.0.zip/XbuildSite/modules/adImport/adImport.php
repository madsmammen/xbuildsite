<?php
class modules_adImport {
  private static $rows;

  function _block__before_header(){
    echo "<h1>Hello modules_adImport ...</h1>";
  }

  function block__adImport_main() {
	  DLog::log("==========");
    $arr = self::get_adGroup();
    $pattern = array();
    $pattern[0] = '/,/';
    $replace = array();
    $replace[0] = ', ';

    $i = 0;
    foreach ($arr as $val) {
      $newStr = preg_replace($pattern, $replace, $val);
      echo "<tr><td><input id=xb__adImportNr" . $i . " type=checkbox></td><td>" . $newStr . "</td></tr>";
      $i++;
    }

    self::$rows = $i;
  }

  function block__adImport_foot() {
    echo "<tr><td>Found: <span id=xb__adImportSel1>0</span>/" . self::$rows . " AD groups</td></tr>";
  }

  function block__adImport_groups() {
    $str = "";
    $app =& Dataface_Application::getInstance();

    $query = "select groupName from `xBuildSite__groups`";

    DLog::log("\$query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
	$str .= ($str != '' ? ',' : '') . '"' . $row[0] . '"';
      }
	    
      DLog::log("Insertion: OK");
    }
    else
      DLog::log("Insertion: FAILED !");

    DLog::log("str: " . $str);
    echo "<input id=xb__adImportGroups type=hidden size=100 value='" . $str ."'/>";
  }

  function _block__before_main_section() {
    echo "block__before_main_section()";

    $grpArr = self::get_adGroup();
    echo "<h1>Import Windows AD groups</h1>";
    // <div <style>
    // #container     {width:30ex; outline:1px solid black; padding:0 .2em; background:white;}
    // #container>div {display:inline-block; margin:.2em 0; background:#fca;}
    // </style>

    // <!-- Scroll bar present and enabled -->        
    echo "<p><div style='height: 250px; outline:1px solid black; padding:0em; overflow-y: scroll;'>";
    echo "<table>";
    echo <<< END
	 <tr>
	   <td></td>
	   <td>Group name</td>
	   <td>Role</td>
         </tr>
END;
    foreach($grpArr as $line) {
      // $str = explode(",", $line);
      // if (substr($str[0], 0, 3) == "CN=") {
      if (preg_match("/CN=[a-zA-Z_-]*SOFD.*,/", $line)) {
        echo "<tr><td colspan=3>$line</td></tr>";
        $str = explode(",", $line);
        $cn = explode("=", $str[0]);
	echo <<< END
	 <tr>
	   <td><input type=checkbox></input></td>
	   <td><label>$cn[1]</label></td>
	   <td><input></input></td>
         </tr>
END;
      }
    }
    echo "</table>";
    echo "</div>";

  }

  function _block__after_main_section() {
    echo "block__after_main_section()";
  }

  function get_adGroup() {
    $arr = array(
        "CN=SharefileUser,OU=XenDesktop 7,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=XDM Bruger,OU=XenDesktop 7,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=CTX_Dit_Digitale_Skrivebord,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_Aveleo_Sundhed,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_OS2_Dagsorden,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Genesys_Agent,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=CTX_XenApp_6.5_Dev-Test,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=CTX_XenApp_6.5,OU=CTX Applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=syddjurs_dk_webmaster,OU=Drupal,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_DNN_Kontraktdatabase,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_ProjektFlow-brugere,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=1_Org_IT_og_Digitalisering_Digitalisering,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_it_nilex,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_Projekt,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_ImportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_Projekt,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_Scripts,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_ExportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SOFD_Dokumentation,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_Dokumentation,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_ExportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_Mifare_Admins,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=P-Skyprinter,OU=print grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_Write_SyddjursDW,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_Scripts,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SEC_Office_Startup_Admins,OU=OfficeSkabeloner,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=SEC_Office_Skabeloner_Admins,OU=OfficeSkabeloner,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_ImportFiler,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=DW_Dotnetnuke_Admins,OU=SOFD,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=P-PR05051,OU=print grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Dpr_Rapport,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Microsoft_Project,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Microsoft_Visio_2010,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_IT_projekt_tools,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Outlook_FreeBusy,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_CtxShadow,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Se_Bruger_Applikationer,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Nilex_Servicedesk,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=1_Lokation_Adm_bygning_Rønde,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=1_Alle,OU=distributionsgrupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_CAG_VPN,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Intranet,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_CAG_webmail,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_ACADRE_PROD_SEPWRITE,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Wordpad,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Internet_Explorer,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_lokale_printere,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=TSShadow,CN=Users,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Remote_desktop,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_KOMMUNEKONCEPT,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Powerarchiver,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Adobe_Acrobat_Reader,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Access,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Office_STD,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Stifinder,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_ACADRE_PROD_CM,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_KPS_Blanket,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_TDC_Digital,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=sec_it,OU=security grupper,OU=grupper,OU=syddjurs,DC=intern,DC=syddjurs,DC=dk",
        "CN=PF_Schultzlovnet,OU=PowerFuse applikationer,DC=intern,DC=syddjurs,DC=dk",
        "CN=TSBruger,CN=Users,DC=intern,DC=syddjurs,DC=dk");
    // DLog::log("count: " . count($arr));
    
    return($arr);

  }
}
?>
