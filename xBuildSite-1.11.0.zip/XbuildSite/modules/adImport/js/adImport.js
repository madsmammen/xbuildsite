//require <jquery.packed.js>
//require-css <adImport.css>

function myFunction() {
  console.log("myFunction()");
}

function but1() {
  console.log("but1()");
  document.getElementById("div1").innerHTML =
  '<tr>' +
  '  <td>cell 3</td>' +
  '  <td>cell 4</td>' +
  '</tr>';
}

function but2() {
  console.log("but2()");
  document.getElementById("demo").innerHTML =
    '<table id="Table" class=sc>' +
    '  <thead>' +
    '    <tr><th>1:</th><th>2:</th></tr>' +
    '  </thead>' +
    '  <tr>' +
    '    <td>cell 1</td>' +
    '    <td>celoikl 2</td>' +
    '  </tr>' +
    '  <tr>' +
    '    <td>cell 3</td>' +
    '    <td>cell 4</td>' +
    '  </tr>' +
    '</table>';
}

  var $ = jQuery;
  // var table = $('#oTable').DataTable();

function rows() {
  var $ = jQuery;
  var row = $('#ioTable tr').length;
  console.log("ioTable: row: " + row);
  var row = $('#xb__adImportBody tr').length;
  console.log("xb__adImportBody: row: " + row);
  var row = $('#oTable tr').length;
  console.log("row: " + row);
}	

$('#xb__adImportTbl2 tbody').on( 'click', 'tr', function () {

  var row = $('#xb__adImportTbl2 tr').length;
  console.log("Rows: " + row);
 //  console.log( table.row( this ).data() );

} );


function addScroll() {
  var $ = jQuery;
  console.log("addScroll()");
  $table = $('table.sc'),
  $bodyCells = $table.find('tbody tr:first').children(), colWidth;
  $(window).resize(); 
}

function numberCells()
{
	var count=1;
	var oTable = document.getElementById('oTable');
	var RowsLength = oTable.rows.length;
	for (var i=1; i < RowsLength; i++) {
	    var oCells = oTable.rows.item(i).cells;
	    var CellsLength = oCells.length;
	    for (var j=0; j < CellsLength; j++) {
		    oCells.item(j).innerHTML = count++;
	    }
	}
}

function loopForm(form) {
    var cbResults = 'Checkboxes: ';
    var radioResults = 'Radio buttons: ';
    for (var i = 0; i < form.elements.length; i++ ) {
        if (form.elements[i].type == 'checkbox') {
            if (form.elements[i].checked == true) {
                cbResults += form.elements[i].value + ' ';
            }
        }
    }
    document.getElementById("cbResults").innerHTML = cbResults;
}

$(":checkbox").change(function() {
  countSel1();
});

function countSel1() {
  var nr = 0;
    $('#xb__adImportTable').find('input[type="checkbox"]:checked').each(function () {
       //this is the current checkbox
       nr++;
    });

  console.log("nr1: " + nr);
  document.getElementById("xb__adImportSel1").innerHTML = nr;
}

function countSel2() {
  var nr = 0;
    $('#xb__adImportTbl2').find('input[type="checkbox"]:checked').each(function () {
       //this is the current checkbox
       nr++;
    });

  console.log("nr2: " + nr);
  document.getElementById("xb__adImportSel2").innerHTML = nr;
}


(function(){
  var $ = jQuery;
  $(document).ready(function(){
    $('#xb__adImportSelExtract').click(function() {
      var isSelected = false;
      console.log("xb__adImportSelExtract()");
      
// var t = document.getElementById("xb__adImportBody").getElementsByTagName("tr");
// console.log("t: " + t.length);
// console.log("t[1]: " + $("#xb__adImportBody").children()[1].children[1].innerHTML  );
      

      var res, innerHtml = "";
      var row = $('#xb__adImportBody tr').length;
      // var body = document.getElementById("xb__adImportBody");
      // console.log(body);

      var str = document.getElementById("xb__adImportGroups").value;
      console.log("xb__adImportGroups: " + str);
      var grpArray = eval("[" + document.getElementById("xb__adImportGroups").value + "]");
      console.log("xb__adImportGroups: " + grpArray.length);

      function xb__adImportFind(str) {
	console.log("xb__adImportFind: " + str);
	for (var i=0; i < grpArray.length; i++) {
	  // console.log("Compare '" + str + "' with '" + grpArray[i] +"'");
	  if (grpArray[i] == str)
	    return(true);
	}
	return(false);
      }

      console.log("xb__adImportSelExtract()");
      console.log("rown: " + row);

      // Check if any groups is selected
      for (var i=0, nr=-1; i < row; i++) {
	if (document.getElementById("xb__adImportNr" + i).checked)
	  isSelected = true;
      }
      if (! isSelected) {
        alert("Please select at least 1 AD group");
	return;
      }
      
      // Process the selected AD groups
      for (var i=0, nr=-1; i < row; i++) {
	if (document.getElementById("xb__adImportNr" + i).checked) {
	  nr++;
          var str =  $("#xb__adImportBody").children()[i].children[1].innerHTML; // $('#xb__adImportBody tr').body.rows[i].innerHTML; 
          str = str.replace(/<\/?[^>]+(>|$)/g, "");
	  console.log("str: " + str);

	  var res = str.match(/CN=[a-zA-Z-_ .0-9]*/); 
	  res = res[0].substr(3, res[0].length);
	  console.log("res: " + res + " str: " + str);
	  rc = xb__adImportFind(res);
	  console.log("==> " + (rc ? "FOUND" : "NOT FOUND"));
          innerHtml += "<tr><td><input id=xb__adImportCb" + nr + " type=checkbox " + (rc ? "disabled" : "checked") + "></input></td>" +
	    "<td style='min-width:150px'><input type=hidden id='xb__adImportInput" + nr + "' value='" + res + "'>" +
	    "<label>" + res +
	    "</label></td>" +
	    "<td width='100%'><input id='xb__adImportComment" + nr + "' style='display:table-cell; width:99%'></input></td>" +
	    "<td id='xb__adImportSelectTd" + nr + "'><select id='xb__adImportSelect" + nr + "'>" +
	    "  <option>Please select ..</option>" +
	    "  <option>NO ACCESS</option>" +
	    "  <option>READ ONLY</option>" +
	    "  <option>EDIT</option>" +
	    "  <option>DELETE</option>" +
	    "  <option>ADMIN</option>" +
	    "</select>" +
	    "</td></tr>";
	}
      }

      nr++;
      document.getElementById("xb__adImportTbl").innerHTML = 
        '<table id=xb__adImportTbl2 class="sc" cellspacing=10px width=100%>' +
        '  <thead id=xb__adImportHead2>' +
        '    <tr><th></th><th>AD group</th><th>Description</th><th>Access</th></tr>' +
        '  </thead>' +
        '  <tbody id=xb__adImportBody2 style="max-height:330px; white-space: nowrap">' +
	     innerHtml +
        '  </tbody>' +
	'  <tfoot>' +
	'    <tr><td>Import: <span id=xb__adImportSel2>0</span> of ' + nr + ' AD groups</td></tr>' +
	'  </tfoot>' +
        '</table>';

      // document.getElementById("xb__adImportStep1").style = "display:none";
      // document.getElementById("div1").style.display = "none";
      document.getElementById("xb__adImportStep1").style.display = "none";
      // document.getElementById("whathere").style.display = "block";
      document.getElementById("xb__adImportStep2").style.display = "block";
      document.getElementById("xb__adImportNote").style.display = "block";
      addScroll();

      // Redefine the '.change' function
      $(":checkbox").change(function() {
        countSel2();
      });
      countSel2();

    })
  });
})();


(function(id){
  var $ = jQuery;
  $(document).ready(function(){
    $('#xb__adImportFind').click(function(){
      var	regex, res, rowNr, substr, str;
      var	select = [];
      console.log("xb__adImportFind(): '" + $('#xb__adImportFilter').val() + "'");

      // var body = document.getElementById("xb__adImportBody");
      // rowNr = body.rows.length;
      rowNr = $('#xb__adImportBody tr').length;
      // console.log(document.getElementById("xb__adImportBody").rows.length);
      // regex = "/" + $('#xb__adImportFilter').val() + "/g";
      regex = $('#xb__adImportFilter').val();
      console.log("regex: " + regex);
      console.log("rowNr: " + rowNr);

      // Save initial 'select' state
      for (var i=0; i < rowNr; i++) {
	select[i] = document.getElementById("xb__adImportNr" + i).checked;
      }

      for (var i=0; i < rowNr; i++) {
        // str = body.rows[i].innerHTML; 
	str = $("#xb__adImportBody").children()[i].children[1].innerHTML;
	substr = str.split("</td>");
	// console.log("substr[0]: " + substr[0] + ", [1]: " + substr[1]);

	console.log(str);
	console.log(substr);
        res = substr[0].replace(regex, "<span style=background-color:yellow>" +
	       	$('#xb__adImportFilter').val() + "</span>"); 
	if (substr[0] != res)
	  select[i] = true;
	//if (substr[1] != res)
	  //document.getElementById("xb__adImportNr" + i).checked = true;
	/*
	  document.getElementById("xb__adImportNr0").checked = true;
	  var ele = document.getElementById("xb__adImportNr" + i);
	  document.getElementById("xb__adImportNr" + i).check = true;
	  ele.check = true;
 console.log("xb__adImportNr" + i + ele.checked);
	*/

        // body.rows[i].innerHTML = substr[0] + res;
	// console.log( body.rows[i].innerHTML);
	$("#xb__adImportBody").children()[i].children[1].innerHTML = res; // substr[0] + res;
      }
      for (var i=0; i < rowNr; i++) {
	if (select[i]) document.getElementById("xb__adImportNr" + i).checked = true;
      }
      countSel1();
   
      /*
      var i, cars = ["Saab", ["bil1", "bil2"], "Volvo", "BMW"];
      for(i=0; i < cars.length; i++) {
	if (Array.isArray(cars[i])) {
	  console.log("isArray()");
	  var arr = cars[i];
          for(var j=0; j < arr.length; j++)
	    console.log("  [" + j + "]: " + arr[j]);
	}
	else
	  console.log("[" + i + "]: " + cars[i]);
      }
      */
    });
  });
})();

(function(){
    var $ = jQuery;
    $(document).ready(function(){
        $('#xb__adImportImport').click(function(){
	  var isSelected = true, hasAllAccess = true;
          console.log("xb__adImportImport()");

          var table = document.getElementById("xb__adImportBody2");
	  // console.log("rows: " + table.rows.length);
          var str, select, groups = "";

	  // console.log("xb__adImportImport()");
	  var rows = $('#xb__adImportBody2 tr').length;
          console.log("rown: " + table.rows.length);

          // Check if any groups is selected
          for (var i=0; i < rows; i++) {
	    if (! document.getElementById("xb__adImportCb" + i).checked)
	      isSelected = false;
	    if (document.getElementById("xb__adImportSelect" + i).value == "Please select ..")
	      hasAllAccess = false;
          }

          if (! hasAllAccess) {
            alert("Please choose the 'access'");
	    return;
          }

          if (! isSelected) {
            alert("Please select at least 1 AD group to import");
	    return;
          }

	  // Import each line into 'xBuildSite__groups'
          console.log("Rows: " + rows);
          for (var i=0; i < rows; i++) {
            // console.log(i + ":: " + table.rows[i].innerHTML);
	    console.log("adImport" + i + ": " + document.getElementById("xb__adImportCb" + i).value);
	    if (document.getElementById("xb__adImportCb" + i).checked) {
	      console.log("Checkox(" + i + ").checked");
              select = document.getElementById("xb__adImportSelect" + i).value;

	      str = document.getElementById("xb__adImportInput" + i).value + "," +
                document.getElementById("xb__adImportComment" + i).value + "," + select;
              console.log("str: " + str);
	      var ret = do_import(str);
              ret = ret.replace(/ /g, "&nbsp;");
              ret = ret.replace(/FAILED/, "<span style=color:red>FAILED</span>");
              ret = ret.replace(/OK/, "<span style=color:green><b>OK</b></span>");
	      console.log("ret: " + ret);
	      document.getElementById("xb__adImportSelectTd" + i).innerHTML = ret;
              // console.log(i + ":: " + table.rows[i].innerHTML);
	    }
	  }
	  // document.getElementById("xb__adImportImport").style = "display:none";
	  document.getElementById("xb__adImportNote").style.display = "none";
	  addScroll();
        });
    });
})();

var $ = jQuery;

// Change the selector if needed
var $table = $('table.sc'),
    $bodyCells = $table.find('tbody tr:first').children(), colWidth;

$(window).resize(function() {
    // console.log("resize");
    // Get the tbody columns width array
    colWidth = $bodyCells.map(function() {
        return $(this).width();
    }).get();
    
    // Set the width of thead columns
    $table.find('thead tr').children().each(function(i, v) {
        $(v).width(colWidth[i]);
    });    
    console.log("adImport::resize.js");
}).resize(); // Trigger resize handler


// var do_import = function(id) {
function do_import(id) {
  console.log("do_import()");

  var body = document.getElementById("xb__adImportBody");
  var result = "unset";
  console.log(body);

  console.log("do_import()");

  // Call the php to insert the new group
  var $ = jQuery;
    $.ajax({
	// url: '/xBuildSite/doImport.php',
        // crossDomain: true,
	url: '../js/doImport.php',
	async: false, 				// Force 'doImport.php' to execute syncronous
        type: 'POST',
        data: {id:id},
        success: function(data, textStatus, XMLHttpRequest) {
            console.log("data: " + data + ", textStatus: " + textStatus); // Inspect this in your console
	    result = data;
        }
    });
  return(result);
};

$("#button").click(function(){
  console.log("button nr 1");
    $.ajax({url: "/xBuildSite/modules/adImport/js/demo_test.txt", success: function(result){
        $("#div1").html(result);
    }});
}); 

function Import(id) {
 console.log("_import");
     $.ajax({
       // url: "/xBuildSite/modules/adImport/demo_test.txt",
       url: 'doImport.php',
       // url: '/xBuildSite/modules/doImport.php',
       // url: '/xBuildSite/adImport.php',
       async: false,  
       type: 'POST',
       data: {id:id},
	     /*
       success: function(result){
          $("#div2").html("OK");
       }
       */
       success: function(data, textStatus, XMLHttpRequest) {
         console.log("data: " + data + ", textStatus: " + textStatus); // Inspect this in your console
       }
     });
 console.log("button2");
}
