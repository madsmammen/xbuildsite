//require <jquery.packed.js>
//require-css <hello_world.css>
//require-css <xataface/modules/hello_world/hello_world.css>

(function(){
var $ = jQuery;
$(document).ready(function(){
	$('#update-user-name-btn').click(function(){
	// On click handler for the button with id update-user-name-btn
        // Take the value of the user-name-field and place it in the
	// user-name span:
	$('#user-name').text($('#user-name-field').val());
	});
});})();
