<?php

// require_once DATAFACE_PATH . "/modules/adLDAP/src/adLDAP.php";


class actions_hello_world {
  function handle($params){
    // echo "<h1>Hello World actions/hello_world.php</h1>"
    DLog::log("actions_hello_world::handle()");

    $auth =& Dataface_AuthenticationTool::getInstance();
    $app =& Dataface_Application::getInstance();
    $creds = $auth->getCredentials();

    DLog::log("func checkCredentials()");

    if (isset($auth))
      DLog::log("isset(\$auth)");
    else
      DLog::log("!isset(\$auth)");

    if (isset($creds))
      DLog::log("isset(\$creds)");
    else
      DLog::log("!isset(\$creds)");

    if (is_array($creds)) {
      // $creds = array("hej" => "mads");
      DLog::log("isarray(\$creds), count: " . count($creds));
      foreach ($creds as $value) {
        DLog::log("creds: $value");
      }
    }
    else
      DLog::log("!isarray(\$creds)");



    $user = $creds['UserName'];
    $user = $auth->getLoggedInUsername(); // & $auth->getLoggedInUser();
    $user =& $auth->getLoggedInUser(); // & $auth->getLoggedInUser();

    $adldap = new adLDAP();
    $user = "mwbm";

    // DLog::log("Uid: " . $user->val('role') . ", password: '");
    // DLog::log("Uid: " . $user . ", password: '");
    // DLog::log("Uid: " . $user . ", password: " . $creds['Password'] . ", val: ");
    // $authUser = $adldap->user()->authenticate($user, $creds['Password']);
    $authUser = $adldap->user()->authenticate($user, 'Mathias3');
    if ($authUser) {
      DLog::log("authUser: OK");
      $user = $adldap->user()->infoCollection($user, array('*'));
      if ($user) {
        DLog::log("info: OK: " . $user->displayName);
	$groupArray = $user->memberOf; 
	// if (false) 
        foreach ($groupArray as $group) {
	  // if (preg_match("/sofd/i", $group))	// The "i" after the pattern delimiter indicates a case-insensitive search
  	    DLog::log("group: " . $group);
        }
      }
    }
    else
      DLog::log("authUser: FAILED !!");

    $adldap->close();
    DLog::log("handle() << end");


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    $javascriptTool->addPath(
      dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/hello_world/js' // The URL to the js dir
    );
    $javascriptTool->import('hello_world.js');

    $cssTool = Dataface_CSSTool::getInstance();
    $cssTool->addPath(dirname(__FILE__).'/../css',
    	    DATAFACE_SITE_URL.'/modules/hello_world/css');
    
    df_register_skin('hello world skin', dirname(__FILE__).'/../templates');
    df_display(array(), 'hello_world_template.html');
  }
}
?>
