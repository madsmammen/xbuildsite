<?php
class modules_hello_world {
  function _block__before_header(){
    echo "<h1>Hello World ...</h1>";
  }
}
?>
