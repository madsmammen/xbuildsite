//require <jquery.packed.js>

function xb__adGroupOnload() {
  var i, innerHtml = "";

  console.log("xb__adGroupOnload()");
  // document.getElementById("xb__adGroupBody").innerHTML = "Paragraph changed!";
  var txt = document.getElementById("xb__adGroupGroups").value;
  var arrGrp = eval(txt);
  console.log("lenght: " + arrGrp.length);

  for (i=0; i < arrGrp.length; i++) {
     console.log("arrGrp[" + i + "]: " + arrGrp[i]);
     innerHtml += "<tr><td><input id=xb__adGroupNr" + i + " type=checkbox></input></td><td>" + arrGrp[i] + "</td></tr>\n";
  }
  // innerHtml = "<table id=xb__adGroupeTable>" + innerHtml + "</table>";
  console.log("innerHtml: " + innerHtml);
  document.getElementById("xb__adGroupBody").innerHTML = innerHtml;
     
  // innerHtml += "<tr><td><input type=checkbox></input></td><td>" + arrGrp[i] + "</td></tr>\n";
}

(function(){
    var $ = jQuery;
    $(document).ready(function(){
        $('#xb__adGroupReload').click(function(){
	  
            // On click handler for the button with id update-user-name-btn
            // Take the value of the user-name-field and place it in the
            // user-name span:
            // $('#user-name').text($('#user-name-field').val());
	    console.log("xb__adGroupReload: ");
        });
    });
})();

(function(){
  var $ = jQuery;
  $(document).ready(function(){
    $('#xb__adGroupSelExtract').click(function(){
      console.log("xb__adGroupSelExtract()");
      var table = document.getElementById("xb__adGroupBody");
      var innerHtml = "";

      console.log("xb__adGroupSelExtract()");
      console.log("rown: " + table.rows.length);
      for (var i=0, nr=0; i < table.rows.length; i++) {
	console.log("value: " + document.getElementById("xb__adGroupNr" + i).checked);
        console.log(i + ": " + table.rows[i].innerHTML);
	if (document.getElementById("xb__adGroupNr" + i).checked) {
	  nr++;
          var str = table.rows[i].innerHTML; 
	  var res = str.match(/CN=[a-zA-Z-_ .0-9]*/); 
	  console.log("res: " + res[0]);
          // innerHtml += "<tr><td><input id=xb__adGroupNr" + nr + " checked></input></td></tr>\n";
          innerHtml += "<tr><td><input id=xb__adGroupCb" + nr + " type=checkbox checked></input></td>" +
	    "<td><input type=hidden id='xb__adGroupInput" + nr + "' value='" + res[0].substr(3, res[0].length) + "'>" +
	    "<label>" + res[0].substr(3, res[0].length) +
	    "</label></td>" +
	    "<td width='90%'><input id='xb__adGroupComment" + nr + "' style='display:table-cell; width:100%' _size=40></input></td>" +
	    "<td id='xb__adGroupSelectTd" + nr + "'><select id='xb__adGroupSelect" + nr + "'>" +
	    "  <option>Please select ..</option>" +
	    "  <option>NO ACCESS</option>" +
	    "  <option>READ ONLY</option>" +
	    "  <option>ADMIN</option>" +
	    "</select>" +
	    "</td></tr>";
	}
      }
      innerHtml = "<tr><th></th><th height=34pt><label>Group</label></th><th><label>Comment</label></th>" +
	    "<th><label>Access</label></th></tr>" + innerHtml;
      console.log("innerHtml: " + innerHtml);
      // document.getElementById("xb__adGroupHead").innerHTML = 
	    "<th colspan=3><label>Group</label></th><th><label>Description</label></th><th><label>Access - role</label></th>";
      // document.getElementById("xb__adGroupHead").style = "display:display";
      document.getElementById("xb__adGroupBody").innerHTML = innerHtml;
      document.getElementById("xb__adGroupExtract").style = "display:none";
      document.getElementById("xb__adGroupImport").style = "display:display";
      console.log(innerHtml);
      // document.getElementById("xb__adGroupReload").innerHTML  = "<button id='xb__adGroupImport'>Import</button>";
    });
  });
})();

(function(){
    var $ = jQuery;
    $(document).ready(function(){
        $('#xb__adGroupImport').click(function(){
          var table = document.getElementById("xb__adGroupBody");
	  console.log("rows: " + table.rows.length);
          var str, select, groups = "";

          console.log("xb__adGroupImport()");
          console.log("rown: " + table.rows.length);
          for (var i=1; i < table.rows.length; i++) {        // There is a heading
            // console.log(i + ":: " + table.rows[i].innerHTML);
	    console.log("adGroup" + i + ": " + document.getElementById("xb__adGroupInput" + i).value);
	    if (document.getElementById("xb__adGroupCb" + i).checked) {
	      console.log("Checkox(" + i + ").checked");
	      // groups += (i==1 ? "" : ", ") + document.getElementById("xb__adGroupInput" + i).value;
              select = document.getElementById("xb__adGroupSelect" + i).value;
	      select = (select == "Please select .." ? "" : select);
	      document.getElementById("xb__adGroupSelectTd" + i).innerHTML = "Importing...";
	      groups += (i==1 ? "" : ", ") + "\"" + document.getElementById("xb__adGroupInput" + i).value + ", " +
                document.getElementById("xb__adGroupComment" + i).value + ", " + select + "\"";

	      str = "\"" + document.getElementById("xb__adGroupInput" + i).value + ", " +
                document.getElementById("xb__adGroupComment" + i).value + ", " + select + "\"";
	      str = eval("[" + str + "]");
              console.log("str: " + str);
	      var ret = do_import(str);
	      console.log("ret: " + ret);
	      document.getElementById("xb__adGroupSelectTd" + i).innerHTML = ret;
	    }
	  /*
	    console.log("value: " + document.getElementById("xb__adGroupNr" + i).checked);
            console.log(i + ": " + table.rows[i].innerHTML);
	    if (document.getElementById("xb__adGroupNr" + i).checked) {
              var str = table.rows[i].innerHTML; 
	    }
	  */
	  }

	  /*
	  str = eval("[" + groups + "]");
          console.log("str: " + str);
	  do_import(str);
	  */
        });
    });
})();

(function(id){
  var $ = jQuery;
  $(document).ready(function(){
    $('#xb__adGroupPhp').click(function(){
      console.log("xb__adGroupPhp()");
      var i, cars = ["Saab", ["bil1", "bil2"], "Volvo", "BMW"];
      for(i=0; i < cars.length; i++) {
	if (Array.isArray(cars[i])) {
	  console.log("isArray()");
	  var arr = cars[i];
          for(var j=0; j < arr.length; j++)
	    console.log("  [" + j + "]: " + arr[j]);
	}
	else
	  console.log("[" + i + "]: " + cars[i]);
      }
      /*
      $.ajax({
	      // url: 'test.php?argument=value&foo=bar'
	 url: '/xBuildSite/test.php',
         data: {action: 'test'},
         type: 'post',
	 // dataType: 'json',
         success: function(output) {
                    alert("Return: '" + output + "'");
         }
      });
      */
    });
  });
})();

function don() {
  return("HH");
}

// var do_import = function(id) {
function do_import(id) {
  console.log("do_import()" + don());
  var $ = jQuery;
    $.ajax({
	url: '/xBuildSite/test.php',
        type: 'POST',
        data: {id:id},
        success: function(data) {
            console.log("data: " + data); // Inspect this in your console
	    // return("OK");
        }
    });
  return("done_imp");
};
