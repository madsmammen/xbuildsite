<?php

require_once DATAFACE_PATH . "/modules/Auth/adLdap/adLDAP/src/adLDAP.php";

class actions_appGroups {
  function handle($params) {
    DLog::log("actions_appGroups()");

    $auth =& Dataface_AuthenticationTool::getInstance();
    $app =& Dataface_Application::getInstance();
    $creds = $auth->getCredentials();


    $javascriptTool = Dataface_JavascriptTool::getInstance();
    $javascriptTool->addPath(
      dirname(__FILE__).'/../js', // The Path to the js dir
      DATAFACE_SITE_URL.'/modules/appGroups/js' // The URL to the js dir
    );
    $javascriptTool->import('appGroups.js');
    // $javascriptTool->import('adGrp.js');
    
    // df_register_skin('appGroup skins', dirname(__FILE__).'/../templates');
    df_register_skin('appdGroups skin', dirname(__FILE__).'/../');
    df_display(array(), 'appGroups_template.html');
  }
}
?>
