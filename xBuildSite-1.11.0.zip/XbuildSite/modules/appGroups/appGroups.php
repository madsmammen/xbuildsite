<?php
class group_ele {
  var $group;
  var $role;
  var $use = 0;
};

// static $groups = array();
class modules_appGroups {

  static $groups = array("hej");
  

  function _modules_appGroups() {
    DLog::log("modules_appGroups()");
    $app =& Dataface_Application::getInstance();
    $query = "select * from xBuildSite__groups";
    DLog::log("query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
      $nr = 0;
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
	DLog::log($nr . ": groupName: " . $row['groupName'] . ", access: " . $row['access']);
	$ele = new group_ele;
	$ele->group = $row['groupName'];
	$ele->role = $row['access'];
	// self::$groups[$nr++] = $row['groupName'];
        self::$groups[$nr++] = $ele;
      }
      DLog::log("modules_appGroups() count: " . count(self::$groups));
      xf_db_free_result($res);
    }
    else {
      DLog::log("modules_appGroups(): query FAILED !!");
    }
  }

  function block__appGroups_main() {
    echo "modules_appGroups::block__main()";
    DLog::log ("modules_appGroups::block__main()" . self::$groups);
    $app =& Dataface_Application::getInstance();
    $auth =& Dataface_AuthenticationTool::getInstance();
    $creds = $auth->getCredentials();

    $query = "select * from xBuildSite__sites";
    DLog::log("query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
      // echo "<thead><tr><th>Site</th><th>Title</th></tr></thead>";
         // echo "<thead style='display: block'><tr><th>Site</th><th>Title</th></tr></thead>";
         echo "<thead><tr><th>Site</th><th>App. group</th><th>Access</th><th>&nbsp&nbsp</th></tr></thead>";
         // echo "<tbody style='height: 150px; display: block; width: 100%; overflow: auto;'><tr><td>Sitexx</td><td>Titleyy</td></tr>";
	 echo "<tbody>";
         // echo "<tr><td>Sitexx</td><td>Titleyy</td></tr>";
      //  echo "<tbody style='height: 250px; display: inline-block; width: 100%; overflow: auto;'>";

      DLog::log("query OK");
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
        echo "<tr><td><b>" . $row['site'] . "</b></td><td></td><td></td></tr>";
	/*
        echo "<tr><td>" . $row['site'] . "</td>" . // <td>" . $row['title'] . "</td>" .
             "<td>" . $row['authGrp'] . "</td></tr>";
	 */
	DLog::log("authGrp: '" . $row['authGrp'] . "'");
	$arr = explode(chr(10), $row['authGrp']);
	DLog::log("explode: " . count($arr));
	if ($arr[0] != '') {
	  for ($i=0; $i < count($arr); $i++) {
	    // echo "<th><tr><td></td><td>" . $arr[$i] . "</td></th>";
	    echo "<tr><td></td><td>" . $arr[$i] . "</td><td>" . self::getRole($arr[$i]) . "</td></tr>";
	  }
        }
      }
      echo "</tbody>";
      xf_db_free_result($res);
    }
    else {
      DLog::log("block__appGroups_main(): query FAILED !!");
    }
    
  }

  function block__appGroups_notUsed() {

    echo "<thead><tr><th></th><th>App. group</th><th>use count</th><th>&nbsp&nbsp</th></tr></thead>";
    echo "<tbody height=100px>";
    for($i=0; $i < count(self::$groups); $i++) {
      $ele = self::$groups[$i];
      if ($ele->use == 0) {
	echo "<tr><td></td><td>$ele->group</td><td>$ele->use</td></tr>";
      }
    }
    echo "</tbody>";
    // $app->redirect($values['--query']);

    $app = Dataface_Application::getInstance();

    if ( class_exists('Dataface_AuthenticationTool')) {
      $auth = Dataface_AuthenticationTool::getInstance();
      if ($auth->isLoggedIn())
        DLog::log("auth:'"); //  . ($auth->isLogedIn() ? "TRUE" : "FALSE") . "'");
      else
        DLog::log("No isLogginIn()");
    }
    else
      DLog::log("No class !!");

    DLog::log("Session: '" . $_SESSION['UserName'] . "'");

  }

  function getRole($grp) {
    // $ele = self::$groups[3];
    // DLog::log("getRole() count: " . $ele->group . count(self::$groups));
    for($i=0; $i < count(self::$groups); $i++) {
      $ele = self::$groups[$i];
      if ($ele->group == $grp) {
	$ele->use++;
        return($ele->role);
      }
    }
    return("Role");
  }

  function xb_is_logged_in(){
    $app = Dataface_Application::getInstance();

    if ( class_exists('Dataface_AuthenticationTool') and
	    ($auth = Dataface_AuthenticationTool::getInstance()) and $auth->isLoggedIn())
      echo $auth->isLogedIn();
  }

}
?>
