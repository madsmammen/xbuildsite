<?php
// echo "mark: " . $_POST["mark"];
class DLog {
    private static $logFile;
    private static $NR;
    
    private function init()    {
      if( self::$logFile == null ) {
        self::$logFile = fopen("debug.log",'a');
        // fwrite(self::$logFile, "<=========================>\n" );
        // fwrite(self::$logFile, "init::fopen('debug.log', 'a')\n" );
        fflush(self::$logFile);
	self::$NR = 0;
      }
    }

    public static function log($text) {
      $nr = ++self::$NR;
      self::init();
      // fwrite(self::$logFile, "$nr: $text\n" );
      fflush(self::$logFile);
    }
}
?>
