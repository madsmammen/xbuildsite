// A closure: An anonymous javascript function, that is called
// immediately after creation.

/*
  function xb__regex_eval() {
    console.log('xb__regex_eval()');
    var val = document.getElementById('xb__regex_val').value;
    var regex = document.getElementById('xb__regex').value;
    console.log('RegEx: ' + regex + ', val: ' + val);
    var expr = eval('/^' + regex + '$/');
    var res = val.match(expr);
    console.log('res 2: ' + res + ', expr: ' + expr);
    if (!res)
      alert('Invalid information entered.\n- ' + document.getElementById('message').value + '\nPlease correct there fields');
  }
  */

  function xb__text_display(str) {
    console.log("xb__text_display(): '" + str + "'");
    var val = document.getElementById('type').value;
    console.log("xb__text_display(): '" + val + "'");

    switch (val) {
      case "_Checkbox":
        break;

      case "Select":
	xb__text_select(val);
        break;

      default:
	alert("Can not define properties for a '" + val + "' type");
    }
  }
/*
// import System.IO;
function Start () {
var dirs : DirectoryInfo[] = new DirectoryInfo("/Users/graham").GetDirectories();
var sw : StreamWriter = new System.IO.StreamWriter("DriveDirs.txt");
sw.WriteLine("Found the following folder:");
for (var dir : DirectoryInfo in dirs){
sw.WriteLine(dir.Name);
}
sw.Close();
var sr : StreamReader = new System.IO.StreamReader("DriveDirs.txt");
Debug.Log(sr.CurrentEncoding);
var line : String;
while (!sr.EndOfStream) {
line = sr.ReadLine();
Debug.Log(line);
}
}
     
*/
  // import System.IO;

  function Start() {
    loc = window.location.pathname;
    console.log("patrhname: " + loc);
    if (window.File && window.FileReader && window.FileList && window.Blob) {
      // Great success! All the File APIs are supported.
    } else {
      alert('The File APIs are not fully supported in this browser.');
    }
    try {
      // Create an instance of StreamReader to read from a file.
      sr = new StreamReader("c:/xampp/htdocs/xBuildSite/TestFile.txt");
      // Read and display lines from the file until the end of the file is reached.
      line = sr.ReadLine();
      while (line != null) {
        console.log(line);
        line = sr.ReadLine();
      }
      sr.Close();
    }
    catch (e) {
      // Let the user know what went wrong.
      console.log("The file could not be read:");
      console.log(e.Message);
    }
  }


  function xb__text_select(str) {
    console.log("xb__text_select(): '" + str + "'");

    Start();
    var s = '<table class=_xb__table id=xb__table border=1 width=450pt>' +
   '  <!-- Table heading -->' +
   '  <tr><th colspan=4>' +
   '    <table class=xb__table id=xb__table width=100%>' +
   '      <tr>' +
   '        <td width=15% align=left><img src="images/help.gif" alt="" style="vertical-align:middle;" onclick=xb__regex_display("show-help")>' +
   '        </td>' +
   '        <td>Define dynamic selection</td>' +
   '        <td width=15% align=right><img src="images/delete.gif" alt="" style="vertical-align:middle;" onclick=xb__regex_display("hide")>' +
   '        </td>' +
   '      </tr>' +
   '    </table>' +
   '    </th>' +
   '  </tr>' +
   '<!--' +
   '   <tr><th colspan=3>Define selection list type:</th>' +
   '     <td align=right><input type="button" value="x" onclick=_close()>' +
   '     </td>' +
   '   </tr>' +
   '-->' +
   '<!--' +
   '   <tr>' +
   '     <td width=35%><input class="sinput" id="selectType" type="input" value="type"></td>' +
   '     <td width=25%>c</td>' +
   '     <td width=30%>c</td>' +
   '     <td>c</td>' +
   '   </tr>' +
   '-->' +
   '<!--' +
   '   <tr>' +
   '     <th colspan=3 align=left>' +
   '       Select type: <select id="selectionType" name="selectionType" onchange=selectType()>' +
   '         <option>Static select</option>' +
   '         <option>Dynamic select</option>' +
   '       </select>' +
   '     </th>' +
   '   </tr>' +
   '-->' +
   ' <tbody id=staticList style="display:none">' +
   '   <tr class="collapse">' +
   '   <th colspan=3 align=left>' +
   '     <select id="selection" name="selection" size=5  width="390" style="width: 390px">' +
   '       <_option>Grp1 = "Group 1"</_option>' +
   '     </select>' +
   '   </th>' +
   '   <td>' +
   '     <input type="button" name="up" value="^" onclick="move("up")"><br>' +
   '     <input type="button" name="down" value="v" onclick="move("down")"><br>' +
   '     <input type="button" name="del" value="del" onclick="del()"><br>' +
   '     </td>' +
   '   </tr>' +
   '   <tr>' +
   '   <th colspan=1 align=left>Id:' +
   '     <input type="input" id=inp_id name="inp_id" size=12>' +
   '   </th>' +
   '   <th colspan=2 align=left>Value:' +
   '     <input type="input" id=inp_val name="inp_val" size=25>' +
   '   </th>' +
   '   <td><input type="button" name="add" value="add" onclick="add()"></td>' +
   '   </tr>' +
   ' </tbody>' +
   ' <!-- Dynamic select list -->' +
   ' <tbody id=dynamicList style="display:display">' +
   ' <tr>' +
   '   <th colspan=1 align=left>Table:' +
   '     <select id="dyn_table" name="dyn_table" _style="width:200pt">' +
   '        <option>Please Select ...</option>';
  }


//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
