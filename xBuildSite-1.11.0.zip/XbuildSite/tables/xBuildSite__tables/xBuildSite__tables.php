<?php
class tables_XbuildSite__tables {

  function __sql__() {
    if (false)
      return "select f.* from xBuildSite__tables f join xBuildSite__userinfo u on f.site = u.currSite " .
	   " and f.table = u.currTable where u.user = 'xAdmin'";
    else
      return "select f.* from xBuildSite__tables f join xBuildSite__userinfo u on f.site = u.currSite " .
	   " where u.userName = 'xAdmin'";
  }

  function site__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function tableName__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function table__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function order__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }
} 
