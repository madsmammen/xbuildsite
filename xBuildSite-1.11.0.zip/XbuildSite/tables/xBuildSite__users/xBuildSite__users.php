<?php
class tables_XbuildSite__users {

  function password__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }
}
