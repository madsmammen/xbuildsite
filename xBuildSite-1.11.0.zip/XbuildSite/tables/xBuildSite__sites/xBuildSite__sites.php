<?php
class tables_XbuildSite__sites {

  function site__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function database__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function discName__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function __sql__() {
    if (false)
      return "select * from xBuildSite__sites";
    else
      return "select f.* from `xBuildSite__sites` f join `xBuildSite__userinfo` u " .
             " on f.site = u.currSite where u.userName = 'xAdmin'";
  }

} 
