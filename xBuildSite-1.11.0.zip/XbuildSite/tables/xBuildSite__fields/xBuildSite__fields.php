<?php
/*
 * function field__full_name(Dataface_Record $record){
    return $record->val('first_name').' '.$record->val('last_name');
 }
 */
class tables_XbuildSite__fields {

  function _init(&$table) {
    /*
    $fields =& $table->fields();
    $fields[$fieldname]['visibility']['list'] = 'hidden'; if they are not selected. 
    */
    DLog::log("-------fields__init()");
    $app =& Dataface_Application::getInstance();
    $i = $app->_conf['_database']['driver'];
    // $i = $app->_fields['_database']['driver'];
    DLog::log("----i: '" . $i . "'");
  }

  function __sql__() {
    if (false)
      return "select * from xBuildSite__fields where `site` = 'mySite'";
    else
      return "select f.* from xBuildSite__fields f left join xBuildSite__userinfo u on " .
             " f.site = u.currSite AND f.tableName = u.currTable where u.userName = 'xAdmin'";
  }

  function site__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function tableName__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function columnName__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function declared__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function isNull__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function block__before_site_widget() {
    echo "<span style='font-size:120%; _font-weight:bold'>";
  }

  function block__after_site_widget() {
    echo "</span>";
  }

  function block__after_validate_widget() {
    DLog::log("block__after_validate_widget()");
    
    echo <<< END
      <img src="images/edit.gif" alt="edit" style="vertical-align:middle; border:0px solid gray"
	    onclick='xb__regex_display("show");'>
      <span id="xb__validate"></span>
END;

    /*
    Dataface_JavascriptTool::getInstance()->import('xb__regex_eval.js'); 
    Dataface_JavascriptTool::getInstance()->import('xb__regex_press.js'); 
    Dataface_JavascriptTool::getInstance()->import('xb__regex_display.js'); 
    Dataface_JavascriptTool::getInstance()->import('xb__regex_selecter.js'); 
    require_once 'block__after_validate_widget.php';
    */
  }

  function block__after_type_widget() {
    echo <<< END
      <img src="images/edit.gif" alt="edit" style="vertical-align:middle; border:0px solid gray"
	    onclick='xb__type_display("show");'>
      <span id="xb__type"></span>
END;
    // return;

    $app =& Dataface_Application::getInstance();
    // $query = "show tables where tables_in_test NOT LIKE 'dataface__%' AND tables_in_test NOT LIKE 'xBuildSite__%'";
    $query = "show tables";
    DLog::log("\$query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res) {
      $str = "";
      while ($row = xf_db_fetch_array($res, MYSQL_NUM)) {
        if (! preg_match('/^dataface__*|xbuildsite__*/',$row[0]))
	  $str = $str . ($str == "" ? '"' : ', "') . $row[0] . '"';
        // echo "<option>" . $row[0] . "</option>";
      }
      echo "<br><input id=xb__select_listTables type=hidden size=100 value='[" . $str . "]'>";
      DLog::log("str: " . $str);
      xf_db_free_result($res);
    }
    else
      DLog::log("Failed !");


    return;


    $app =& Dataface_Application::getInstance();
    // Dataface_JavascriptTool::getInstance()->import('xb__text_display.js'); 
    
    /*
    $javascriptTool = Dataface_JavascriptTool::getInstance();
    // $mt = Dataface_ModuleTool::getInstance();
    // $mod = $mt->loadModule('modules_adImport');

    echo "<br>Path: " . dirname(__FILE__).'\..\..\..\js';
    $javascriptTool->addPath(dirname(__FILE__).'\..\..\js', // The Path to the js dir
      DATAFACE_SITE_URL.'/js' // The URL to the js dir
    );
    $javascriptTool->import('xb__text_display.js');
     */
/*
    $ct = Dataface_CSSTool::getInstance();
    // $ct->addPath(dirname(__FILE__).'/css', $mod->getBaseURL().'/css');
    $ct->addPath(dirname(__FILE__).'/../css',  DATAFACE_SITE_URL.'/modules/adImport/css');
    $ct->import('adImport.css');
 */


    // Add an 'edit' button
    echo <<<END
      <img src="images/edit.gif" alt="" style="vertical-align:middle" border="1" onclick=xb__text_display('show')>
      <br><div id=xb__text_replace>To be replaced</div>
END;




    /*
    DLog::log("block__after_text_widget()");
    require_once 'block__after_text_widget.php';
    after_text_widget();
    */
  }


  /*
  function vis__permissions($record){
    return array('edit'=>0, 'new'=>0);
  }

  function __block__before_left_column() {
  }
 
  function __getTitle() {
    return "HEJSA";
  }
   */

  function _block__after_new_record_form() {
    echo "block__after_new_record_form";
  echo <<<END
  <script language="javascript">
  var slave_field= document.getElementById('slave');
  var master_field = document.getElementById('master');
END;
  // Let's get all the slaves available.
  $app =& Dataface_Application::getInstance();
  $query =& $app->getQuery();
  $table =& Dataface_Table::loadTable($query['-table']);
  $slaves = $table->getValuelist('slaves_list');
  $slave_masters = $table->getValuelist('slaves_list__meta');
  // Note that the slaves_list__meta valuelist is automatically created
  // because we had three columns in the slaves valuelist.
  // The first and third columns effectively create a 2nd valuelist
  // named 'slaves_list__meta'

  // $slaves is an array with keys slave_id and values slave_name
  // slave_masters is an array with keys slave_id and values master_id

  import('Services/JSON.php');
  $json =& new Services_JSON(); // A JSON encoder to allow us to easily
                                // convert PHP arrays to javascript arrays.
  echo '
  var slaves_options = '.$json->encode($slaves).';
  var slaves_master = '.$json->encode($slave_masters).';
  ';

  echo <<<END
  master_field.onchange = function() {
    var selected_master = master_field.options[master_field.selectedIndex].value;
    slave_field.options.length = 0;
    var index = 0;
    for ( slave_id in slaves_options) {
      if ( selected_master == slaves_master[slave_id]) {
        slave_field.options[index++] = new Option(slaves_options[slave_id], slave_id);
      }
    }
  };
  </script>
END;
  echo "done slaves: " . count($slaves) . ", masters: " . count($slave_masters);
}

  // Also place this javascript after an edit record form...
  function _block__after_edit_record_form() {
    echo "block_after__edit_record_form()";
    return $this->block__after_new_record_form();
  }
  
  function _status__renderCell(Dataface_Record $record) {
    Dataface_JavascriptTool::getInstance()->import('editable_status.js'); 

    $options = array(
      'Select...',
      'Open',
      'Closed',
      );
    $currVal = $record->val('status');
    $out = array();
    $out[] = '<font size=1><select class="status-drop-down"
      data-record-id="' . htmlspecialchars($record->getId()) . '">';
    foreach ( $options as $opt ) {
      $selected = ($currVal === $opt) ? 'selected':'';
      $out[] = '<option value="' . htmlspecialchars($opt) . '" ' . $selected.'>'
      .htmlspecialchars($opt) . '</option>';
    }
    $out[] = '</select></font>';
    // echo 'count(): ' . count($out) . ': [0]' . $out[0];
    return implode("\n", $out);
  }

  function nullGrp__renderCell(Dataface_Record $record) {
    Dataface_JavascriptTool::getInstance()->import('editable_nullGrp.js'); 

    $options = array(
      '',
      'Null group 1',
      'Null group 2',
      'Null group 3',
      'Null group 4',
      'Null group 5',
      );
    $currVal = $record->val('nullGrp');
    $out = array();
    $out[] = '<font size=1><select class="nullGrp-drop-down"
      data-record-id="' . htmlspecialchars($record->getId()) . '">';
    foreach ( $options as $opt ) {
      $selected = ($currVal === $opt) ? 'selected':'';
      $out[] = '<option value="' . htmlspecialchars($opt) . '" ' . $selected.'>'
      .htmlspecialchars($opt) . '</option>';
    }
    $out[] = '</select></font>';
    // echo 'count(): ' . count($out) . ': [0]' . $out[0];
    return implode("\n", $out);
  }

  function vis__renderCell(Dataface_Record $record) {
    Dataface_JavascriptTool::getInstance()->import('editable_vis.js'); 

    $options = array(
      'Visible',
      'Required',
      'Not editable',
      'Hidden'
      );
    $currVal = $record->val('vis');
    $out = array();
    $out[] = '<font size=1><select class="vis-drop-down"
      vis-data-record-id="' . htmlspecialchars($record->getId()) . '">';
    foreach ( $options as $opt ) {
      $selected = ($currVal === $opt) ? 'selected':'';
      $out[] = '<option value="' . htmlspecialchars($opt) . '" ' . $selected.'>'
      .htmlspecialchars($opt) . '</option>';
    }
    $out[] = '</select></font>';
    return implode("\n", $out);
  }

  function _type__renderCell(Dataface_Record $record) {
    Dataface_JavascriptTool::getInstance()->import('editable_type.js'); 

    $options = array(
      '...',
      'Checkbox',
      'Select',
      'Lookup',
      'day',       // day, month, year select
      'year',      // year select
      );
    $currVal = $record->val('type');
    $out = array();
    $out[] = '<font size=1><select class="type-drop-down"
      data-record-id="' . htmlspecialchars($record->getId()) . '">';
    foreach ( $options as $opt ) {
      $selected = ($currVal === $opt) ? 'selected':'';
      $out[] = '<option value="' . htmlspecialchars($opt) . '" ' . $selected.'>'
      .htmlspecialchars($opt) . '</option>';
    }
    $out[] = '</select></font>';
    // echo 'count(): ' . count($out) . ': [0]' . $out[0];
    return implode("\n", $out);
  }

  function group__renderCell(Dataface_Record $record) {
    Dataface_JavascriptTool::getInstance()->import('editable_group.js'); 

    $options = array(
      '',
      'Group #1',
      'Group #2',
      'Group #3',
      'Group #4',
      'Group #5',
      );
    $currVal = $record->val('group');
    $out = array();
    $out[] = '<font size=1><select class="group-drop-down"
      data-record-id="' . htmlspecialchars($record->getId()) . '">';
    foreach ( $options as $opt ) {
      $selected = ($currVal === $opt) ? 'selected':'';
      $out[] = '<option value="' . htmlspecialchars($opt) . '" ' . $selected.'>'
      .htmlspecialchars($opt) . '</option>';
    }
    $out[] = '</select></font>';
    // echo 'count(): ' . count($out) . ': [0]' . $out[0];
    return implode("\n", $out);
  }
} 

