<?php
function block__after_validate_widget() {
}
  DLog::log("block__after_testing_widget.php()");
  // echo "<style>" .
       "  th, td {" .
       "      border: 0px solid black;" .
       "  }" .
       "  .xb__table {" .
       "      border: 1px solid black;" .
       "  }" .
       "  tr.collapse {" .
       "      // visibility: collapse;" .
       "      visibility: display;" .
       "  }" .
       "</style>";
  echo <<<END

    <img src="images/edit.gif" alt="edit" style="vertical-align:middle; border:0px solid gray" onclick='xb__regex_display("show");'>

    <br>
    <table class=xb__table border=1>
      <tbody id=xb__table style="display:none">
      <tr><th colspan=2>
        <table class=xb__table id=xb__table width=100%>
          <tr>
            <td width=15% align=left><img src="images/info_icon.gif" alt="" style="vertical-align:middle"
	                                  border="1" onclick='xb__regex_display("show-help");'>
	    </td>
            <td>Regular expression testing (RegEx)</td>
            <td width=15% align=right><img src="images/delete.gif" alt="" style="vertical-align:middle"
	                                  border="1" onclick='xb__regex_display("hide");'>
	    </td>
	    <!---
        <td><input id=xb__regex type=text size=50 title="This RegEx has to match the entire input. (the regex is surrounded by '^' and '$')" value="\d{4}"></td>
	  -->
          </tr>
        </table>
      </th>
      </tr>
      <tr>
      <!---
        <td><input id=xb__regex type=text size=50 title="This RegEx has to match the entire input. (the regex is surrounded by '^' and '$')" value='\d{4}'></td>
	-->
	<td><input id=xb__regex value='\d{4}'></td>
        <td><select id="xb__regex_select" onchange='xb__regex_selecter();'>
           <option value="" selected>Predefined ...</option>
           <option value="\d{4}!\d: any digit, {4}: 4 times">postal no</option>
	   <!--
           <option value="\d{8}!\d: any digit, {8}: 8 times">telephone no</option>
           <option value="[A-Za-z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}![A-Za-z0-9._%+-]+: 1 or more of [.], a '@', [..]+: 1 or more [.], a '.', [..]{2,4}: 2, 3 or 4 of [.]">
	      email</option>
	    <option value="(mailto|MAILTO)\:[A-Za-z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}![A-Za-z0-9._%+-]+: 1 or more of [.], a '@', [..]+: 1 or more [.], a '.', [..]{2,4}: 2, 3 or 4 of [.]">
	      mailto</option>
	      <option value="[A-Za-z0-9_-]{3,16}!'[A-Za-z0-9_-]': any upper or lower case char, digit, '_' or '-', '{3,16}': 3 times uptil 16 times">user name</option>
	      -->
	 </td>
      </tr>
      <tr>
	<td><input id=xb__regex_val type=input size=50 value="1243" onclick='console.log("click");'
		 onkeypress="xb__regex_press(event)"></td>
        <td align=right><input type="button" value="eval" onclick=xb__regex_eval()></td>
      </tr>
      <!---
      <tr>
        <td><input style="font-size:6pt" type="button" value="?" onclick=xb__regex_eval()></td>
	<td><label style="width:50px;border:1px solid #000;" onclick=console.log('xx')>?</label></td>
      </tr>
       -->
      <tr>
        <td width=60pt><label id=xb__regex_explain style="font-size:80%">?</label></td>
      </tr>
      <tr>
	<td>Error message:<br>
  	  <input id=xb__regex_msg type=input size=50 value="">
	</td>
      </tr>
      <tr>
	<td></td>
        <td align=right><input type="button" value="save" onclick='xb__regex_display("save");'></td>
      </tr>

      </tbody>
      <tbody id=xb__regex_help style="display:none">
      <tr><th colspan=2>
        <table class=xb__table id=xb__table width=450pt>
          <tr>
            <td width=15% align=left></td>
            <td>Regular expressions</td>
            <td width=15% align=right><img src="images/delete.gif" alt="" style="vertical-align:middle"
	                                  border="1" onclick='xb__regex_display("hide-help");'>
	    </td>
          </tr>
        </table>
      </th>
      </tr>
      <tr> <!-- <th colspan=2> -->
	<td colspan=2>
        <table width=100% id=xb__regex_help border=1>
          <tr>
	    <td width=18%>Expr.</td>
	    <td>Description</td>
          </tr>
          <tr>
	    <td>[abc]</td>
	    <td>Find any of the characters between the brackets</td>
          </tr>
          <tr>
	    <td>[0-9]</td>
	    <td>Find any of the digits between the brackets</td>
          </tr>
          <tr>
	    <td>(x|y)</td>
	    <td>Find any of the alternatives separated with |</td>
          </tr>
          <tr>
	    <td>{#} or {#,#}</td>
	    <td>Exactly '#' occurence or between '#' and '#'</td>
          </tr>
          <tr>
	    <td>Meta</td>
	    <td>Metachracters</td>
          </tr>
          <tr>
	    <td>\d</td>
	    <td>Find a digit</td>
          </tr>
          <tr>
	    <td>\s</td>
	    <td>Find a whitespace character</td>
          </tr>
          <tr>
	    <td>\b</td>
	    <td>Find a match at the beginning or at the end of a word</td>
          </tr>
          <tr>
	    <td>Apear</td>
	    <td>Quantifiers i.e. appearence times</td>
          </tr>
          <tr>
	    <td>n+</td>
	    <td>Matches any string that contains at least one n</td>
          </tr>
          <tr>
	    <td>n*</td>
	    <td>Matches any string that contains zero or more apear. of n</td>
          </tr>
          <tr>
	    <td>n?</td>
	    <td>Matches any string that contains zero or one apear. of n</td>
          </tr>
      <!--
-->
        </table>
	</div>
      </td>
      </tr>
      </tbody>
    </table>
    <!-- -->
END
?>
