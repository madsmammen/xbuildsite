<?php
function after_text_widget() {
  $app =& Dataface_Application::getInstance();

  DLog::log("Block__after_text_widget.php()");
  /*
  echo <<<END
      <style>
        th, td {
            border: 0px solid black;
        }
        .xb__table {
            border: 1px solid black;
        }
        tr.collapse {
            // visibility: collapse;
            visibility: display;
        }
      </style>
  END;
   */

  echo <<<END
  <img src="images/edit.gif" alt="" style="vertical-align:middle" border="1" onclick='xb__text_display("show");'>

    <table class=_xb__table id=xb__table border=1 width=450pt>

      <!-- Table heading -->
      <tr><th colspan=4>
        <table class=xb__table id=xb__table width=100%>
          <tr>
            <td width=15% align=left><img src="images/help.gif" alt="" style="vertical-align:middle;"
	                                  onclick='xb__regex_display("show-help");'>
	    </td>
            <td>Define dynamic selection</td>
            <td width=15% align=right><img src="images/delete.gif" alt="" style="vertical-align:middle;"
	                                  onclick='xb__regex_display("hide");'>
	    </td>
          </tr>
        </table>
      </th>
      </tr>


<!--
      <tr><th colspan=3>Define selection list type:</th>
        <td align=right><input type="button" value="x" onclick=_close()>
        </td>
      </tr>
      -->
      <tr>
        <td width=35%><input class="sinput" id="selectType" type="input" value=" type + '"></td>
        <td width=25%>c</td>
        <td width=30%>c</td>
        <td>c</td>
      </tr>
<!--
      <tr>
        <th colspan=3 align=left>
          Select type: <select id="selectionType" name="selectionType" onchange=selectType()>
            <option>Static select</option>
            <option>Dynamic select</option>
          </select>
        </th>
      </tr>
-->
    <tbody id=staticList style="display:none">
      <tr class="collapse">
      <th colspan=3 align=left>
        <select id="selection" name="selection" size=5  width="390" style="width: 390px">
          <_option>Grp1 = "Group 1"</_option>
        </select>
      </th>
      <td>
        <input type="button" name="up" value="^" onclick="move("up")"><br>
        <input type="button" name="down" value="v" onclick="move("down")"><br>
        <input type="button" name="del" value="del" onclick="del()"><br>
        </td>
      </tr>
      <tr>
      <th colspan=1 align=left>Id:
        <input type="input" id=inp_id name="inp_id" size=12>
      </th>
      <th colspan=2 align=left>Value:
        <input type="input" id=inp_val name="inp_val" size=25>
      </th>
      <td><input type="button" name="add" value="add" onclick="add()"></td>
      </tr>
    </tbody>

    <!-- Dynamic select list -->
    <tbody id=dynamicList style="display:display">
    <tr>
      <th colspan=1 align=left>Table:
        <select id="dyn_table" name="dyn_table" _style="width:200pt">
           <option>Please Select ...</option>
END;
  $query = "show tables where tables_in_test NOT LIKE 'dataface__%' AND tables_in_test NOT LIKE 'xBuildSite__%'";
  DLog::log("\$query: $query");
  $res = xf_db_query($query, $app->db());
  if ($res) {
    while ($row = xf_db_fetch_array($res, MYSQL_NUM)) {
      echo "<option>" . $row[0] . "</option>";
    }
    xf_db_free_result($res);
  }

  echo <<<END
        </select>
      </th>
      <th colspan=1 align=left>Id:
        <select id="dyn_id" name="dyn_id">
          <option>Please Select ...</option>
        </select>
      </th>
      <th colspan=1 align=left>Name:
        <select id="dyn_name" name="dyn_name">
          <option>Please Select ...</option>
        </select>
      </th>
    </tr>
    </tbody>
  </table>
END;
}
?>
