<?php
class tables_XbuildSite__userinfo {

  function __password__permissions($record) {
    return array('edit'=>0, 'new'=>0);
  }

  function __getPermissions(&$record){
    /*
    $user =& Dataface_AuthenticationTool::getInstance()->getLoggedInUser();
    if ( $user and $user->val('role') == 'EDITOR' ){
        return Dataface_PermissionsTool::getRolePermissions('EDITOR');
    } else if ( $user and $user->val('role') == 'MANAGER' ){
        return Dataface_PermissionsTool::getRolePermissions('MANAGER');
    }
     */

    return Dataface_PermissionsTool::READ_ONLY();
  }

  function getRoles(&$record){
    /*
    $user =& Dataface_AuthenticationTool::getInstance()->getLoggedInUser();
    if ( $user and $user->val('role') == 'EDITOR' ){
        return 'EDITOR';
    } else if ( $user and $user->val('role') == 'MANAGER' ){
        return 'MANAGER'
    }
     */
    return 'READ ONLY';
}
}
