// A closure: An anonymous javascript function, that is called
// immediately after creation.

  String.format = function() {
    var s = arguments[0];
    for (var i = 0; i < arguments.length - 1; i++) {       
      var reg = new RegExp("\\{" + i + "\\}", "gm");             
      s = s.replace(reg, arguments[i + 1]);
    }
  
    return s;
  }

  function func_selectDB() {
    var e = document.getElementById('selectDB');
    var sel = e.options[e.selectedIndex].text;
    console.log(sel);

  }

  function func_selectSite() {
    var submit = false;
    var e = document.getElementById('selectSite');
    var sel = e.options[e.selectedIndex].text;
    var curSite = document.getElementById('__xbuild_site__').value;
    console.log(sel);
    console.log(curSite);
    // alert(sel);

    switch (sel) {
      case 'New Site...':
	    var site = window.prompt('New site name', '');
            if (site != null) {
	      console.log('ok');
	      document.getElementById('__xbuild_site__').value = site;
	      submit = true;
            }
            break;

      case 'Delete Site...':
	    var rc = window.confirm(String.format('Do you want to delete \'{0}\'', curSite));
            if (rc) {
	      console.log('OK to delete the site');
	      submit = true;
            }
            break;

      default:
	    console.log('default');
	    document.getElementById('__xbuild_site__').value = sel;
	      submit = true;
            break;
    }

    if (submit) {
      document.forms["__form__"].submit();
      // document.forms.__form__.submit();
    }
  }

  function func_tableName() {
    var e = document.getElementById('selectTable');
    var sel = e.options[e.selectedIndex].text;

    document.getElementById('__xbuild_table__').value = sel;
    document.getElementById('xb__view_table').innerHTML = 
	    	 "<a id=xb__view_table href='index.php?-table=" + sel + "'>View</a>";

  }

  function func_changeTable() {
    var submit = false;
    var e = document.getElementById('table_name');
    var sel = e.options[e.selectedIndex].text;
    var curTable = document.getElementById('__xbuild_table__').value;

    console.log('func_changeTable()');
    console.log(sel);
    if (sel == 'Delete Table...') {
      var rc = window.confirm(String.format('Do you want to delete table: \'{0}\'', curTable));
      if (rc) {
        console.log('OK to delete the table');
	submit = true;
      }
    }
    else
	submit = true;

    if (submit)
      document.forms["__form__"].submit();
  }

//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
