// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function xb__type_display(str) {
    var $ = jQuery;

    console.log("xb__type_display(): '" + str + "'");
    var val = document.getElementById('type').value;
    console.log("xb__type_display(): '" + val + "'");

    if (str == "hide") {
      $("#xb__type").html("");
      return;
    }

    if (val == "")  {
      alert("Please first select a type of the field");
      return;
    }

    switch (str) {
      case "show":
        if (val == "select")  {
	  include('type-select', 'xb__type');
	  // document.getElementById('xb__selectType').value = val;
	  // document.getElementById("mm").value = val;
	  xb__type_select_init();
	}
        break;

      case "hide":
	$("#xb__type").html("");
        break;

      default:
	alert("Can not handle argument '" + str + "'");
    }
  }

  function xb__type_select_init() {
    var tables = document.getElementById('xb__select_listTables').value;
    var sel_table = document.getElementById('xb__type_select_table');
    var text = document.getElementById('text').value;
    console.log("list of tables: " + tables);
    console.log("text (init): '" + text + "'");

    var res = text.split(";"); 
    console.log("res: " + res.length + ", res[0]: '" + res[0] + "'");

    var arr_tables = eval(tables);
    console.log("#arr_tables: " + arr_tables.length);

    for (var i=0; i < arr_tables.length; i++) {
      // tables.value = arr_tables[i];
      sel_table.options[i+1] = new Option(arr_tables[i], "");
    }
    console.log("selected: " + sel_table.selectedIndex);
    if (text == '')
      console.log("text == ''");
    else
       xb__type_select_load(res[1], res[2], res[3]);

  }

  function xb__type_select_change() {
    var sel_table = document.getElementById('xb__type_select_table');
    var opt = sel_table.options[sel_table.selectedIndex];
    console.log("selected: " + sel_table.selectedIndex + ", text: " + opt.text);

    xb__type_select_load(opt.text);
    console.log("First: " + sel_table.options[0].text);

    // If first entry is 'Please Select ...' -> remove it !
    if (sel_table.options[0].text == 'Please Select ...')
      sel_table.remove(0);
  }

  function xb__type_select_save() {
    console.log("xb__type_select_save()");
    var text = document.getElementById('text');
    var sel_table = document.getElementById('xb__type_select_table');
    var selected = sel_table.options[sel_table.selectedIndex];
    var table = selected.text;

    // Id field
    var sel_id = document.getElementById('xb__type_select_id');
    var id = sel_id[sel_id.selectedIndex].text;
    // Name field
    var sel_name = document.getElementById('xb__type_select_name');
    var name = sel_id[sel_name.selectedIndex].text;

    if (id == 'Please Select ...' || name == 'Please Select ...') {
      alert("Please enter an Id or Name column name");
      return;
    }

    console.log("selected: " + sel_table.selectedIndex + ", text: " + selected.text);
    console.log(">> " + table + ";" + id + ";" + name);

    text.value = "Select;" + table + ";" + id + ";" + name;
  }

  function xb__type_select_load(table, id, name) {
    var sel_table = document.getElementById('xb__type_select_table');
    var sel_id = document.getElementById('xb__type_select_id');
    var sel_name = document.getElementById('xb__type_select_name');

    console.log("xb__type_select_load(" + table + "), id: " + id + ", name: " + name);

    // Remove any old options
    for (var i=sel_name.options.length-1; i>=0; i--) {	// sel_id & sel_name has same options
      sel_id.remove(i);
      sel_name.remove(i);
    }
    
    // Execute SQL: show columns from 'table' 
    var fields = sql_query(table);
    console.log("fields: " + fields);
    fields = eval(fields);

    sel_id.options[0] = new Option("Please Select ...", "");
    sel_name.options[0] = new Option("Please Select ...", "");

    // Fill in the fields in the 'selects'
    for(var i=0; i < fields.length; i++) {
      sel_id.options[i+1] = new Option(fields[i], "");
      sel_name.options[i+1] = new Option(fields[i], "");
    }

    if (table != undefined)
      xb__setSelectedValue(sel_table, table);
    if (id != undefined) {
      xb__setSelectedValue(sel_id, id);
      sel_id.remove(0);
    }
    if (name != undefined) {
      xb__setSelectedValue(sel_name, name);
      sel_name.remove(0);
    }
  }

function xb__setSelectedValue(selectObj, valueToSet) {
    for (var i = 0; i < selectObj.options.length; i++) {
        if (selectObj.options[i].text== valueToSet) {
            selectObj.options[i].selected = true;
            return;
        }
    }
}
