// A closure: An anonymous javascript function, that is called
// immediately after creation.

//require <jquery.packed.js>
//require <xataface/IO.js> 
(function(){
  // Enter javascript code here.
  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  registerXatafaceDecorator(function(node) {
    $('select.nullGrp-drop-down[data-record-id]', node).change(function() {
    var recordId = $(this).attr('data-record-id');
      xataface.IO.update(recordId, {nullGrp : $(this).val()}, function(res) {
        if ( res && res.code == 200 ) {
          // alert('Status updated successfully');
        } else if ( res && res.message ) {
          alert('Failed to update Status: '+res.message);
        } else {
          alert('Failed to update Status. Check server log for details');
        }
      })
    });
  });

  // alert('here I am');
})(); 
