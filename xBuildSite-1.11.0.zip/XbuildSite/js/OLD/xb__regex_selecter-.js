// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function xb__regex_selecter() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }


//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  function xb__regex_select() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }

  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
