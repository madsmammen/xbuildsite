// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function xb__regex_eval() {
    console.log('xb__regex_eval()');
    var val = document.getElementById('xb__regex_val').value;
    var regex = document.getElementById('xb__regex').value;
    console.log('RegEx: ' + regex + ', val: ' + val);
    var expr = eval('/^' + regex + '$/');
    var res = val.match(expr);
    console.log('res 2: ' + res + ', expr: ' + expr);
    if (!res)
      alert('Invalid information entered.\n- ' + document.getElementById('message').value + '\nPlease correct there fields');
  }


//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
