// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function xb__regex_display(str) {
    console.log("xb__display_regex(" + str + ")");
    var table = document.getElementById('xb__table');
    var help = document.getElementById('xb__regex_help');
    var validate = document.getElementById('validate');
    var message = document.getElementById('message');
    var xb__regex = document.getElementById('xb__regex');
    var xb__regex_msg = document.getElementById('xb__regex_msg');

    document.getElementById('xb__regex_select').selectedIndex = 0;
    document.getElementById('xb__regex_explain').innerHTML = "?";

    switch (str) {
      case "show": table.style.display = "";
	    xb__regex.value = validate.value;
	    xb__regex_msg.value = message.value;
	    break;

      case "hide": table.style.display = "none";
	    break;

      case "save": table.style.display = "none";
	    validate.value = xb__regex.value;
	    message.value = xb__regex_msg.value;
	    break;

      case "hide-help":
            table.style.display = "";
	    help.style.display = "none";
	    break;

      case "show-help":
            table.style.display = "none";
	    help.style.display = "";
	    break;
    }
  }



//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  function xb__regex_select() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }

  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
