// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function clickedButton() {
    window.location.href = '/../' + document.getElementById('xbuild').value
  }

//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
