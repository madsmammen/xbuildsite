//require-css <xBuildSite.css>

// A closure: An anonymous javascript function, that is called
// immediately after creation.

  function xb__regex_display(str) {
    // var $ = jQuery;

    console.log("xb__validate_display(): '" + str + "'");
    // var val = document.getElementById('type').value;
    // console.log("xb__text_display(): '" + val + "'");

    switch (str) {
      case "show":
	include('validate', 'xb__validate');
        xb__regex_select_init();
        break;

      case "hide":
	$("#xb__validate").html("");
        break;

      case "show-help":
	$("#xb__validate").html("");
	include('validate-help');
        break;

      case "hide-help":
	$("#xb__validate").html("");
        break;

      case "save":
	xb__regex_save();
        break;

      default:
	alert("Can not handle argument '" + str + "'");
    }
  }

  function xb__regex_select_init() {
    var validate = document.getElementById('validate').value;
    console.log("xb__regex_select_init(): " + validate);
    var res = validate.split(";"); 
    console.log("res: " + res.length + ", res[0]: '" + res[0] + "'");

    if (res.length == 2) {
      document.getElementById('xb__regex').value = res[0];
      document.getElementById('xb__regex_msg').value = res[1];
    }
  }

  function xb__regex_selecter() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }

  function xb__regex_eval() {
    console.log('xb__regex_eval()');
    var val = document.getElementById('xb__regex_val').value;
    var regex = document.getElementById('xb__regex').value;
    console.log('RegEx: ' + regex + ', val: ' + val);
    var expr = eval('/^' + regex + '$/');
    var res = val.match(expr);
    console.log('res 2: ' + res + ', expr: ' + expr);
    if (!res)
      alert('Invalid information entered.\n- ' + document.getElementById('xb__regex_msg').value +
            '\nPlease correct the field');
  }

  function xb__regex_press(e) {
    console.log("press()");
    if (!e) e = window.event;
    var keyCode = e.keyCode || e.which;
    if (keyCode == '13'){
      console.log("Enter");
      xb__regex_eval();
      return false;
    }
  }

function xb__regex_save() {
  console.log("xb__regex_save()");
  var validate = document.getElementById('validate');
  var regex = document.getElementById('xb__regex');
  var message = document.getElementById('xb__regex_msg');

  validate.value = regex.value + ";" + message.value;

}


//require <jquery.packed.js>
//require <xataface/IO.js> 

(function(){
  // Enter javascript code here.
  function xb__regex_select() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }

  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 

/*
(function(){
  // Enter javascript code here.
  function xb__regex_select() {
    console.log("xb__regex_select()");
    var source = document.getElementById('xb__regex_select');
    var nr = source.selectedIndex;
    console.log(source.value);

    var str = source.value;
    var res = str.split("!");
    console.log("res[0]: " + res[0] + ", res[1]: " + res[1]);
    if (res.length == 0)
      console.log("FAILED");

    document.getElementById('xb__regex').value = res[0];
    document.getElementById('xb__regex_explain').innerHTML = res[1];
    document.getElementById('xb__regex_msg').value = "Please enter a valid " + source[nr].text;
  }

  // Get a short handle to the jQuery object
  var $ = jQuery; 


  // registerXatafaceDecorator() is like $(document).ready() except that it may also be called
  // when a node is loaded via ajax.

  // alert('here I am');
})(); 
*/
