// Global JavaScript functions

function include(file, htmlId) {
  var $ = jQuery;
  console.log("Include: '" + file + "', htmlId: " + htmlId +"'");
    $.ajax({url: "/xBuildSite/html/" + file + ".html", 
     async: false, 
     success: function(result){
       $("#" + htmlId).html(result);
    }});
}; 

function sql_query(table) {
  console.log("sql_query(" + table + ")");
  var rc = do_query(table);
  console.log("rc: " + rc);
  return(rc);
}


//require <jquery.packed.js>

function do_query(id) {
  console.log("do_query()");

  console.log("do_query(" + id + ")");

  // Call the php to insert the new group
  var $ = jQuery;
    $.ajax({
	// url: '/xBuildSite/doImport.php',
        // crossDomain: true,
	url: 'SQLShowTables.php',
	async: false, 				// Force 'doImport.php' to execute syncronous
        type: 'POST',
        data: {id:id},
        success: function(data, textStatus, XMLHttpRequest) {
            console.log("data: " + data + ", textStatus: " + textStatus); // Inspect this in your console
	    result = data;
        }
    });
  return(result);
};

