-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2015 at 11:11 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbuildsite__dyntable__columns`
--

CREATE TABLE "xbuildsite__dyntable__columns" (
  "name" varchar(40) NOT NULL,
  "table_name" varchar(40) NOT NULL
)

--
-- Dumping data for table `xbuildsite__dyntable__columns`
--

INSERT INTO `xbuildsite__dyntable__columns` (`name`, `table_name`) VALUES
('cColumn', 'test'),
('cDep', 'test'),
('cLand', 'charregion'),
('cLand', 'test'),
('cMed', 'test'),
('collumn_name', 'xbuildsite__dyntable__columns'),
('column', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('column', 'xbuildsite__fields'),
('cRegion', 'test'),
('cSelect', 'test'),
('cTable', 'test'),
('currSIte', 'xbuildsite__userinfo'),
('currTable', 'xbuildsite__userinfo'),
('description', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('description', 'xbuildsite__fields'),
('display_text', 'ip_tlf'),
('efternavn', 'medarbejder'),
('fornavn', 'medarbejder'),
('grp', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('grp', 'xbuildsite__fields'),
('hide', 'xbuildsite__sites'),
('id', 'dashboard'),
('id', 'land'),
('id', 'phpgen_user'),
('id', 'region'),
('iDep', 'test'),
('iMed', 'test'),
('IP_number', 'ip_tlf'),
('iSelect', 'test'),
('label', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('label', 'xbuildsite__fields'),
('land', 'ip_tlf'),
('land_id', 'region'),
('medarbejder_SqlId', 'ip_tlf'),
('module_name', 'dataface__modules'),
('module_version', 'dataface__modules'),
('mtime', 'dataface__mtimes'),
('mtime', 'dataface__record_mtimes'),
('name', 'charland'),
('name', 'charregion'),
('name', 'dataface__mtimes'),
('name', 'phpgen_user'),
('name', 'xbuildsite__tables'),
('navn', 'land'),
('navn', 'region'),
('o2o_field', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('o2o_field', 'xbuildsite__fields'),
('o2o_id', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('o2o_id', 'xbuildsite__fields'),
('o2o_table', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('o2o_table', 'xbuildsite__fields'),
('page_name', 'phpgen_user_perm'),
('password', 'phpgen_user'),
('password', 'users'),
('perm_name', 'phpgen_user_perm'),
('recordhash', 'dataface__record_mtimes'),
('recordid', 'dataface__record_mtimes'),
('region', 'ip_tlf'),
('site', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('site', 'xbuildsite__fields'),
('site', 'xbuildsite__sites'),
('site', 'xbuildsite__tables'),
('SqlID', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('SqlID', 'ip_tlf'),
('SqlID', 'medarbejder'),
('SqlID', 'test'),
('SqlID', 'xbuildsite__dyntable__columns'),
('SqlID', 'xbuildsite__fields'),
('SqlID', 'xbuildsite__sites'),
('SqlID', 'xbuildsite__tables'),
('status', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('status', 'xbuildsite__fields'),
('table', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('table', 'xbuildsite__fields'),
('table', 'xbuildsite__tables'),
('table_name', 'xbuildsite__dyntable__columns'),
('table_name', 'xbuildsite__dyntable__tables'),
('test', 'ip_tlf'),
('text', 'bibliographies'),
('text', 'yesno'),
('title', 'bibliographies'),
('title', 'xbuildsite__sites'),
('type', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('type', 'xbuildsite__fields'),
('user', 'xbuildsite__userinfo'),
('username', 'users'),
('user_id', 'phpgen_user_perm'),
('val', 'yesno'),
('version', 'dataface__version'),
('vis', 'dataface__view_d2c2c838b05af03df5e7d8f4b'),
('vis', 'xbuildsite__fields');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__dyntable__columns`
--
ALTER TABLE `xbuildsite__dyntable__columns`
 ADD PRIMARY KEY (`name`,`table_name`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
