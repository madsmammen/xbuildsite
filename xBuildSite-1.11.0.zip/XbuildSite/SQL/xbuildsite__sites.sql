-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2015 at 10:42 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbuildsite__sites`
--

CREATE TABLE "xbuildsite__sites" (
"SqlID" int NOT NULL identity(1,1),
  "site" varchar(50) NOT NULL,
  "title" varchar(50) DEFAULT NULL,
  "hide" varchar(50) DEFAULT NULL,
  "discName" varchar(50) DEFAULT NULL
)

ALTER TABLE "xbuildsite__sites"
 ADD PRIMARY KEY ("SqlID");

--
-- Dumping data for table `xbuildsite__sites`
--

INSERT INTO `xbuildsite__sites` (`SqlID`, `site`, `title`, `hide`, `discName`) VALUES
(68, 'mads', NULL, NULL, 'myMads'),
(69, 'mm', NULL, NULL, 'myMm'),
(70, 'IP_telefoni', NULL, NULL, 'myIP_telefoni');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__sites`
--
ALTER TABLE `xbuildsite__sites`
 ADD PRIMARY KEY (`SqlID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `xbuildsite__sites`
--
ALTER TABLE `xbuildsite__sites`
MODIFY `SqlID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=76;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
