-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2015 at 10:45 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbuildsite__fields`
--

CREATE TABLE "xbuildsite__fields" (
"SqlID" int NOT NULL identity(1,1),
  "site" varchar(50) NOT NULL,
  "tableName" varchar(50) NOT NULL,
  "columnName" varchar(50) NOT NULL,
  "declared" varchar(25) NOT NULL,
  "vis" varchar(15) DEFAULT NULL,
  "label" varchar(50) DEFAULT NULL,
  "description" varchar(50) DEFAULT NULL,
  "type" varchar(30) DEFAULT NULL,
  "validate" varchar(30) DEFAULT NULL,
  "message" varchar(50) DEFAULT NULL,
  "grp" varchar(11) DEFAULT NULL,
  "nullGrp" varchar(15) DEFAULT NULL,
  "o2o_table" varchar(50) DEFAULT NULL,
  "o2o_id" varchar(50) DEFAULT NULL,
  "o2o_field" varchar(50) DEFAULT NULL,
  "status" varchar(30) DEFAULT NULL,
  "text" varchar(50) DEFAULT NULL
)


ALTER TABLE "xbuildsite__fields"
 ADD PRIMARY KEY ("SqlID");


--
-- Dumping data for table `xbuildsite__fields`
--

INSERT INTO `xbuildsite__fields` (`SqlID`, `site`, `table`, `column`, `declared`, `vis`, `label`, `description`, `type`, `validate`, `message`, `grp`, `nullGrp`, `o2o_table`, `o2o_id`, `o2o_field`, `status`, `text`) VALUES
(499, 'mads', 'land', 'id', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(500, 'mads', 'land', 'navn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(501, 'mads', 'medarbejder', 'SqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(502, 'mads', 'medarbejder', 'fornavn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(503, 'mads', 'medarbejder', 'efternavn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(504, 'mm', 'medarbejder', 'SqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(505, 'mm', 'medarbejder', 'fornavn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(506, 'mm', 'medarbejder', 'efternavn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(507, 'IP_telefoni', 'tbl_iptelefoni', 'SqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(508, 'IP_telefoni', 'tbl_iptelefoni', 'LokalNr', 'varchar(4)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(509, 'IP_telefoni', 'tbl_iptelefoni', 'DisplayNavn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(510, 'IP_telefoni', 'tbl_iptelefoni', 'Kaede', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(511, 'IP_telefoni', 'tbl_iptelefoni', 'Note', 'varchar(255)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(512, 'IP_telefoni', 'tbl_iptelefoni', 'VoiceMail', 'bit(1)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(513, 'IP_telefoni', 'tbl_iptelefoni', 'Udland', 'bit(1)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(514, 'IP_telefoni', 'tbl_iptelefoni', 'MedarbejderSqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(515, 'IP_telefoni', 'tbl_iptelefoni', 'OrgEnhedSqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(516, 'IP_telefoni', 'tbl_iptelefoni', 'Hovednr', 'bit(1)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(517, 'IP_telefoni', 'tbl_iptelefoni', 'CTI_Navn', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(518, 'IP_telefoni', 'tbl_iptelefoni', 'ServiceNr', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(519, 'IP_telefoni', 'tbl_iptelefoni', 'LineGroup', 'varchar(50)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(520, 'IP_telefoni', 'tbl_iptelefoni', 'SidstGuiOpdateret', 'datetime(6)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(521, 'IP_telefoni', 'tbl_iptelefoni', 'SidstGuiOpdateretAf', 'varchar(10)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(522, 'IP_telefoni', 'tbl_iptelefoni', 'Netwise', 'bit(1)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(523, 'IP_telefoni', 'tbl_iptelefoni', 'LokalNrInt', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(524, 'IP_telefoni', 'tbl_iptelefoni', 'EksternBrugerSqlID', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL),
(525, 'IP_telefoni', 'tbl_iptelefoni', 'BrugerType', 'int(11)', 'Visible', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__fields`
--
ALTER TABLE `xbuildsite__fields`
 ADD PRIMARY KEY (`SqlID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `xbuildsite__fields`
--
ALTER TABLE `xbuildsite__fields`
MODIFY `SqlID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=526;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
