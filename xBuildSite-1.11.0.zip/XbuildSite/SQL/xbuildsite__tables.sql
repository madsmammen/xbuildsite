
--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbuildsite__tables`
--

CREATE TABLE "xbuildsite__tables" (
"SqlID" int NOT NULL,
  "site" varchar(50)  NOT NULL,
  "table" varchar(50) NOT NULL,
  "name" varchar(50)  DEFAULT NULL
)

--
-- Dumping data for table `xbuildsite__tables`
--

INSERT INTO `xbuildsite__tables` (`SqlID`, `site`, `table`, `name`) VALUES
(66, 'mads', 'land', NULL),
(67, 'mads', 'medarbejder', NULL),
(68, 'mm', 'medarbejder', NULL),
(69, 'IP_telefoni', 'tbl_iptelefoni', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__tables`
--
ALTER TABLE `xbuildsite__tables`
 ADD PRIMARY KEY (`SqlID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `xbuildsite__tables`
--
ALTER TABLE `xbuildsite__tables`
MODIFY `SqlID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
