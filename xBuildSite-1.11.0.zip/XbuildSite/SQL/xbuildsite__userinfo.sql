--
-- Table structure for table `xbuildsite__userinfo`
--

CREATE TABLE "xbuildsite__userinfo" (
  "user" varchar(50) NOT NULL,
  "currSIte" varchar(50) DEFAULT NULL,
  "currTable" varchar(50) DEFAULT NULL
)


--
-- Dumping data for table `xbuildsite__userinfo`
--

INSERT INTO `xbuildsite__userinfo` (`user`, `currSIte`, `currTable`) VALUES
('xAdmin', 'IP_telefoni', 'tbl_iptelefoni'),
('xBuild', 'qq', 'IP_qq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__userinfo`
--
ALTER TABLE `xbuildsite__userinfo`
 ADD PRIMARY KEY (`user`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
