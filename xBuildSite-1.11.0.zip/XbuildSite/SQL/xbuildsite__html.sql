-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2015 at 10:53 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `xbuildsite__html`
--

CREATE TABLE "xbuildsite__html" (
"SqlID" int NOT NULL identity(1,1),
  "name" varchar(30) NOT NULL,
  "html" varchar(256) NOT NULL
)

ALTER TABLE "xbuildsite__html"
 ADD PRIMARY KEY ("SqlID");


--
-- Dumping data for table `xbuildsite__html`
--

INSERT INTO `xbuildsite__html` (`SqlID`, `name`, `html`) VALUES
(1, 'Heading 1', '<div class="head">\r\n	<span style="font-size:16px;"><strong>Test Application</strong></span> <img alt="Dash" src="{$ENV.DATAFACE_SITE_URL}/images/website.gif" /> <strong><font size="5">xBuildSite: Gui for creating Xataface database applications</font></stro');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `xbuildsite__html`
--
ALTER TABLE `xbuildsite__html`
 ADD PRIMARY KEY (`SqlID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `xbuildsite__html`
--
ALTER TABLE `xbuildsite__html`
MODIFY `SqlID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
