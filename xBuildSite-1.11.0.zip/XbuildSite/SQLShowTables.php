<?php 
header('Content-Type: application/json');

require_once 'log.php';
require_once '/xampp/htdocs/xataface-2.1.2/dataface-public-api.php';
df_init(__FILE__, '../xataface-2.1.2');
  
function showColumns($table) {
  $app =& Dataface_Application::getInstance();

  DLog::log("showColumns(" . $table . ")");
  $query = "show columns from " . $table;

  DLog::log("\$query: $query");
  $rc = "";
  $res = xf_db_query($query, $app->db());
  if ($res) {
    $fields = array();
    $nr = 0;
    while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
      $fields[$nr++] = $row[0] . " [" . $row[1] . "]";
    }

    return($fields);
  }
  else
    return("Insertion: FAILED !");
  xf_db_free_result($res);
  xf_db_close();

  return("Insertion FAILED !");
}

// $action = $_POST['action'];
$id = $_POST['id'];
echo json_encode(showColumns($id));
// echo json_encode("PP");
// echo "PP";
?>
