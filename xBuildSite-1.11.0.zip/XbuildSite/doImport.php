<?php 
header('Content-Type: application/json');

require_once 'log.php';
require_once '/xampp/htdocs/xataface-2.1.2/dataface-public-api.php';
df_init(__FILE__, '../xataface-2.1.2');
  
function insert($arr) {
  $app =& Dataface_Application::getInstance();

  DLog::log("insert()");
  DLog::log("arr: $arr");
  $args = explode(",", $arr);
  DLog::log("count(): " . count($args) . "args[0]: " . $args[0]);

  // $query = "select * from `xBuildSite__groups` where groupName = '" . $args[0] . "'";
  // DLog::log("\$query: $query");

  // $res = xf_db_query($query, $app->db());
  // if ($res) {
  {
    // $row = xf_db_fetch_array($res, MYSQL_NUM);
    // DLog::log("num: $row[0]");
    // DLog::log("insert");
    $query = "insert into `xBuildSite__groups` (groupName, text, access, display) " .
	   " values ('" . $args[0] . "', '" . $args[1] . "', '" . $args[2] . "', 1)";
    DLog::log("\$query: $query");
    $res = xf_db_query($query, $app->db());
    if ($res)
      return("Insertion: OK");
    else
      return("Insertion: FAILED !");
  }
  /*
  else {
    DLog::log("insert");
  }
   */
  xf_db_free_result($res);
  xf_db_close();

  return("Insertion FAILED !");
}

// $action = $_POST['action'];
$id = $_POST['id'];
echo json_encode(insert($id));
// echo json_encode("PP");
// echo "PP";
?>
