<?php

class conf_ApplicationDelegate {

/* Defined methods:
   startSession():
   beforeHandleRequest():
   block__before_left_column():
   block__after_xf_logo():
   getPreferences():
   create_tables():

*/

function block__custom_javascripts(){
    echo '<script src="xb__text.js" type="text/javascript" language="javascript"></script>';
  }

  function _startSession() {
    DLog::log("---- startSession() ----");
    session_start();
     DLog::log("session_name(): '" . session_name() ."', session_id: '" . session_id() . "'");
  }

  function beforeHandleRequest() {
/*
  class conf_ApplicationDelegate  {
    function beforeHandleRequest() {
    Dataface_Application::getInstance()
      ->addHeadContent('<link rel="stylesheet" type="text/css" href="style.css"/>');
    } 
  } 
*/
    // This is called hefore any table acess is done
    DLog::log("beforeHandleRequest()");

    // Use a $_SESSOIN['firstTime'] variable to check that 'xBuildSite__' tables exist
    // i.e. to avoid more then 1 checking pr. 'startSession()' (request)
    if (isset($_SESSION['firstTime']) && $_SESSION['firstTime'] == "OK") {
      DLog::log("_SESSION['firstTime']: '" . $_SESSION['firstTime'] . "'");
      $_SESSION['firstTime'] = "";
    }
    else {
      DLog::log("! _SESSION['firstTime']");
      /*
      DLog::log("Check for existence of tables"); 
      self::create_tables();
       */
      /*
      $app =& Dataface_Application::getInstance();
      // $driver =  $app->_conf['_database']['driver'];
      // DLog::log("driver: '" . $driver . "'");

      $_SESSION['firstTime'] = "OK";
      $_SESSION['firstTime'] = "";

      $query = "select * from xBuildSite__userinfo_";
      DLog::log("\$query: $query");
  
      $res = xf_db_query($query, $app->db());
      DLog::log("$query << end");
      if ($res) {
        DLog::log("query OK");
      }
      else {
	// 'xBuildSite__' tables must be created !
	// echo "<script>alert('creating tables')</script>";
        DLog::log("query FAILED !!");
      }
       */
    }
  }

  function _getPermissions(&$record) {
    $auth =& Dataface_AuthenticationTool::getInstance();
    $user =& $auth->getLoggedInUser();
    if ( !isset($user) ) return Dataface_PermissionsTool::NO_ACCESS();
      // if the user is null then nobody is logged in... no access.
      // This will force a login prompt.
    $role = $user->val('Role');
    DLog::log("Role: " . $role);
    return Dataface_PermissionsTool::getRolePermissions($role);
     // Returns all of the permissions for the user's current role.
  }

  function block__head_slot() {
    echo '<img src="images/website.gif" alt="Dash"/>' .
         '<font size=5>xBuildSite: Gui for creating Xataface database applications</font>';
  }

  function _block__before_left_column() {
    DLog::log("conf_ApplicationDelegate->block__before_left_column()");
    
    echo "<style media=\"screen\">";
    echo "fieldset {" .
         "font-size:12px;" .
         "  background-color:  #edf3fe;" .  // #dfdfdf
         "  border:  3px solid #bcf;" . // #ccc red: #f00;" .
         "  margin:  2em 0;" .
         "  padding:  0.4em;" .
	 "  padding-top: 0.35em;" .
	 "  padding-bottom: 0.35em;" .
         "}";
    echo "</style>";

    echo "<form action=\"index.php\" method=\"post\" id=\"__form__\">";

    $app =& Dataface_Application::getInstance();
    // echo "conf.ini: " . $app->_conf['_auth']['username_column'] . ", dbtype: " . $app->_conf['_database']['dbtype'];

    $query = "select currSite, currTable from xBuildSite__userinfo where `userName` = 'xAdmin'";
    DLog::log("\$query: $query");

    $res = xf_db_query($query, $app->db());
    if ($res) {
      /* 'XbuildSile__fields */
      DLog::log("$res");
      $row = xf_db_fetch_array($res, MYSQL_ASSOC);
      // echo "Site: " . $row['currSite'] . ", Table: " . $row['currTable'];
      $currSite = $row['currSite'];
      $currTable = $row['currTable'];

      $discName = '';
      $query = "select f.discName from xBuildSite__sites f left join xBuildSite__userinfo u on " .
             " f.site = u.currSite where u.userName = 'xAdmin'";
      $res = xf_db_query($query, $app->db());
      $row = xf_db_fetch_array($res, MYSQL_ASSOC);
      $discName = $row['discName'];
    }
    else
      $currTable = '';
	 
    global $time;
    Dataface_JavascriptTool::getInstance()->import('func_selectSite.js'); 

    echo "<fieldset><legend>Database</legend>" .
	 "<select name=\"selectDB\" id=\"selectDB\" style=width:115pt onchange=\"func_selectDB();\">";

    $query = "show databases";
    // DLog::log("===> \$query: $query");

    $nr = 0;
    $res = xf_db_query($query, $app->db());
    while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
      // SQLLog::log("row[0]: " . $row[0] . ", _conf[]['name']: " . $app->_conf['_database']['name']);
      $nr++;
      if ($row[0] == $app->_conf['_database']['name'])
        echo "<option value=\"$row[0]\" selected=\"selected\">$row[0]</option>";
      else
        echo "<option value=\"$row[0]\">$row[0]</option>";
    }
         // "<label>DB: </label>" .  $app->_conf['_database']['name'] .

    echo "</select></fieldset>";

    echo "<fieldset><legend>xBuildSite</legend>" .
         "<label>Site name:</label><br>" .
         "<input type=\"hidden\" name=\"__xbuild_site__\" ID=\"__xbuild_site__\" Value=\"$currSite\">" .
	 "<select name=\"selectSite\" id=\"selectSite\" style=width:115pt onchange=\"func_selectSite();\">";

    $query = "select distinct site from xBuildSite__sites";
    // DLog::log("===> \$query: $query");

    $nr = 0;
    $res = xf_db_query($query, $app->db());
    while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
      $nr++;
      if ($row[0] == $currSite)
        echo "<option value=\"$row[0]\" selected=\"selected\">$row[0]</option>";
      else
        echo "<option value=\"$row[0]\">$row[0]</option>";
    }
    if ($nr == 0)
       echo "<option value=\"\">Please select...</option>";

    echo "<option value=\"\" disabled>----------------</option>" .
         "<option value=\"NEW\">New Site...</option>" .
         "<option value=\"DEL\">Delete Site...</option>" .
         "</select><p>" .
         "<label>Table name:</label><br>" .
         "<select name=\"table_name\" id=\"table_name\" style=width:115pt onchange=\"func_changeTable()\"><br>";

    /* Find all 'table' for the active site */
    $query = "select distinct f.tableName from xBuildSite__fields f left join xBuildSite__userinfo u on " .
	     "f.site = u.currSite where u.userName = 'xAdmin'";
    // DLog::log("===> \$query: $query");

    $nr = 0;
    $res = xf_db_query($query, $app->db());
    while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
      DLog::log("----> \$row[0]: $row[0]");
      $nr++;
      if ($row[0] == $currTable)
       echo "<option value=\"" . $row[0] . "\" selected=\"selected\">" . substr($row[0], 0, 15) . "</option>";
      else
       echo "<option value=\"" . $row[0] . "\">" . substr($row[0], 0, 15) . "</option>";
    }

    if ($nr != 0)
      echo "<option value=\"\" disabled>----------------</option>" .
           "<option value=\"DEL_TABLE\">Delete Table...</option>";

    echo "</select>" .
         "</fieldset>";
        
    echo "<fieldset><legend>Database table</legend>";
    $db = $app->_conf['_database']['name'];
    if ($app->_conf['_database']['driver'] == "mysql")
      $query = "show tables where `Tables_in_$db` not like 'dataface__%' AND `Tables_in_$db` not like 'xBuildSite__%'";
    else if ($app->_conf['_database']['driver'] == "mssql")
      $query = "show tables where `Table_name` not like 'dataface__%' AND `Table_name` not like 'xBuildSite__%'";

    // DLog::log("===> \$query: $query");

    $res = xf_db_query($query, $app->db());
    $nr = 0;
    if ($res) {
      while ($row = xf_db_fetch_array($res, MYSQL_BOTH)) {
	if ($nr++ == 0) {
          if ($currTable == '') 
            echo "<input type=\"hidden\" name=\"__xbuild_table__\" ID=\"__xbuild_table__\" Value=\"$row[0]\">" .
  	         "<select name=\"selectTable\" id=\"selectTable\" style=width:155pt onchange=\"func_tableName()\";>";
	  else
            echo "<input type=\"hidden\" name=\"__xbuild_table__\" ID=\"__xbuild_table__\" Value=\"$currTable\">" .
  	         "<select name=\"selectTable\" id=\"selectTable\" style=width:155px onchange=\"func_tableName()\";>";
	}
        if ($row[0] == $currTable)
          echo "<option value=\"\" selected = \"selected\">" . $row[0] . "</option>";
	else
          echo "<option value=\"\">" . $row[0] . "</option>";
      }
      echo "</select><br>";
    }
    else 
      DLog::log("FAILED!!");

    echo "<input type=\"submit\" name=\"__xbuild\" Value=\"Load\">&nbsp&nbsp&nbsp" .
         "</fieldset>";

    Dataface_JavascriptTool::getInstance()->import('clickedButton.js'); 
    echo "<fieldset><legend>Write site to disc</legend>" .
         "<input name=\"xbuild__site\" size=\"18\" type=\"text\" value=\"" . $discName . "\" id=xbuild>" .
         "<input type=\"submit\" name=\"__xbuild\" Value=\"Write\">&nbsp&nbsp&nbsp" .
         "<input type=\"button\" value=\"Try it\" onClick=\"clickedButton()\"/>" .
         "</fieldset></form>";
  }
  
  function _beforeHandleRequest() {
    DLog::log("beforeHandleRequest");
  }

  function block__after_xf_logo() {
    $app =& Dataface_Application::getInstance();
    if ($app->_conf['_database']['driver'] == "mssql")
      echo "<script>document.getElementById('xf-logo').innerHTML = " .
	   "'<img align=middle alt=dash src=images/xf-mssql-logo.png " .
	   " width=182 height=37pt style=padding:5px;margin-right:5px;>' " .
           "</script>";
    else if ($app->_conf['_database']['driver'] == "mysql")
      echo "<script>document.getElementById('xf-logo').innerHTML = " .
	   "'<img align=middle alt=dash src=images/xf-mysql-logo.png " .
	   " width=182 height=37pt style=padding:5px;margin-right:5px;>' " .
           "</script>";
    // 152 x 39
  }

  function getPreferences() {
    return array('disable_select_rows'=>1);
  }

   function _beforeLoadResultSet() {
	   /*
      $contact_call_info = new \xf\db\DynamicTable("xbuildsite__dyntable__tables",    // MUST be lower case
      array(
        "create table `xBuildSite__dyntable__tables` (
          table_name VARCHAR(40), PRIMARY KEY (table_name) )",
        "insert into `xBuildSite__dyntable__tables` (`table_name`) values (now())",
        "INSERT INTO `xBuildSite__dyntable__tables`
         SELECT TABLE_NAME FROM information_schema.TABLES 
         WHERE TABLE_SCHEMA = 'test' AND TABLE_NAME NOT LIKE 'dataface__%' 
         AND TABLE_NAME NOT LIKE 'xBuildSite__%' ORDER by TABLE_NAME"
      ),
      array(
	 // "information_schema.TABLES",
	 "xbuildsite__sites"
      )
      );
      $contact_call_info->update();
	    */
   }

  function create_tables() {
    DLog::log("create_tables()");
    $app =& Dataface_Application::getInstance();

    $sqlArr = array();
    // xBuildSite__fields:
    $sqlArr[0] = "create table if not exists xBuildSite__globals (" .
             "  recordhash varchar(32) not null primary key," .
             "  recordid varchar(255) not null" .
             ")";

    for ($i=0; $i < count($sqlArr); $i++) {
      $query = $sqlArr[$i];
      // DLog::log("\$sqlArr: $query");
      $res = xf_db_query($query, $app->db());
      // DLog::log("$query << end");
      if ($res) {
        // DLog::log("query OK");
      }
      else {
        DLog::log("create_tables(): query FAILED !!");
      }
    }
    return;
  }

  function before_authenticate() {
    DLog::log("before_authenticate()");
    if (false) {
    $adldap = new adLDAP();
    // Kint::trace();
    $authUser = $adldap->user()->authenticate("mwbm", "Mathias3");
    if ($authUser) {
      DLog::log("AuthUser: OK");
      $user = $adldap->user()->infoCollection("mwbm", array('*'));
      if ($user) {
        DLog::log("info: OK: " . $user->displayName);
	$groupArray = $user->memberOf; 
	if (false) 
        foreach ($groupArray as $group) {
  	  DLog::log("group: " . $group);
        }

	$userinfo = $adldap->user()->info('AD.mwbm', array("firstname"));
	if ($userinfo)
          DLog::log("userinfo OK");
	else
          DLog::log("userinfo FAILED !!");
	DLog::log("Userinfo: " . $userinfo[0]["firstname"], $userinfo[0]);
      }
      else
        DLog::log("info: FAILED !!");
    }
    else
      DLog::log("authUser: FAILED !!;" . $adldap->getLastError());

    }
    DLog::log("before_authenticate() << end");
  }

  function after_action_logout() {
    DLog::log("after_action_logout(conf)");
    DLog::log("Welcome back to the site: " . $_COOKIE['userlogin']); 
    $_SESSION["adLDAP"] = null;
    $_SESSION["adLDAP_user"] = null;
    $_SESSION["adLDAP_authUser"] = null;
  }

  function after_action_login() {
    /*
    $adLDAP = $_SESSION["adLDAP"];
    $userStr = $_COOKIE["adLDAP_user"];
    $authUser = $_SESSION["adLDAP_authUser"];
    $user = unserialize($userStr);
    DLog::log("After_action_login(conf)" . ($user == null ? "null" : $userStr->displayName));
    // setcookie("adLDAP_user", $userStr, 90000, "/", "localhost");	// Close at session end
    //
    $adldap = $_SESSION["adLDAP"];
    $user = $_SESSION["adLDAP_user"];
    $u = $adldap->user()->infoCollection('mwbm', array('*'));
    DLog::log("u: OK: " . $u->displayName);
    $adLDAPStr = serialize($adLDAP);
    setcookie("adLDAP", $adLDAPStr, 90000, "/", "localhost");	// Close at session end
     */

    DLog::log("after_action_login() << end");
  }

  function loginFailed($username, $userIp, $time){
    DLog::log("Failed login for username: $username at IP $userIp at time $time");
    error_log("Failed login for username: $username at IP $userIp at time $time");
  }

}
