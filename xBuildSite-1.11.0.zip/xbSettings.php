<?php
  /* This file 'xbSettings.php' is used to define the xataface settings for
     xBuildSite and the genarated site's
   */

  $xataface = "xataface";
  $xatafacePath = "/xampp/htdocs";
  $xatafaceRelative = "./$xataface";


  // require_once '/xampp/htdocs/xataface/dataface-public-api.php';
  // df_init(__FILE__, '../xataface');
?>
